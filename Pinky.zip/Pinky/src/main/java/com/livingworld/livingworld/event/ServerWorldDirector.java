package com.livingworld.livingworld.event;

import com.livingworld.livingworld.LivingWorldConfig;
import com.livingworld.livingworld.home.HomeMemorySystem;
import com.livingworld.livingworld.network.LivingWorldNetwork;
import com.livingworld.livingworld.prank.ClientActionType;
import com.livingworld.livingworld.prank.DragonPrankSystem;
import com.livingworld.livingworld.prank.MobSwarmPrankSystem;
import com.livingworld.livingworld.prank.PrankBlockPlan;
import com.livingworld.livingworld.prank.PrankSpawnPlan;
import com.livingworld.livingworld.sanity.SanitySystem;
import com.livingworld.livingworld.watcher.WatcherSystem;
import com.livingworld.livingworld.world.BlockOdditySystem;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class ServerWorldDirector {
    private static final Map<UUID, Long> NEXT_WORLD_EVENT_TICK = new HashMap<>();
    private static final Map<UUID, Long> NEXT_WATCHER_TICK = new HashMap<>();
    private static final Map<UUID, Long> NEXT_DRAGON_PRANK_TICK = new HashMap<>();
    private static final Map<UUID, Long> NEXT_MOB_SWARM_TICK = new HashMap<>();

    private static final Map<UUID, Long> NEXT_CURSOR_PRANK_TICK = new HashMap<>();
    private static final Map<UUID, Long> NEXT_ITEM_THEFT_TICK = new HashMap<>();
    private static final Map<UUID, Long> NEXT_CROUCH_TICK = new HashMap<>();
    private static final Map<UUID, Long> NEXT_JUMP_TICK = new HashMap<>();
    private static final Map<UUID, Long> NEXT_SOUND_TICK = new HashMap<>();
    private static final Map<UUID, Long> NEXT_SLIPPERY_TICK = new HashMap<>();

    private ServerWorldDirector() {
    }

    public static void onServerTick(MinecraftServer server) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            tickPlayer(player);
        }
        DragonPrankSystem.tick(server);
        MobSwarmPrankSystem.tick(server);
    }

    public static void onPlayerLogin(ServerPlayer player) {
        long now = player.serverLevel().getGameTime();
        UUID id = player.getUUID();
        RandomSource random = player.getRandom();

        NEXT_WORLD_EVENT_TICK.put(id, now + 20L * 5L);
        NEXT_WATCHER_TICK.put(id, now + 20L * 20L);
        NEXT_DRAGON_PRANK_TICK.put(id, now + LivingWorldConfig.getDragonPrankIntervalTicks());
        NEXT_MOB_SWARM_TICK.put(id, now + LivingWorldConfig.getMobSwarmIntervalTicks());

        NEXT_CURSOR_PRANK_TICK.put(id, now + randomRangeTicks(random, 35, 80));
        NEXT_ITEM_THEFT_TICK.put(id, now + randomRangeTicks(random, 45, 90));
        NEXT_CROUCH_TICK.put(id, now + randomRangeTicks(random, 30, 80));
        NEXT_JUMP_TICK.put(id, now + randomRangeTicks(random, 30, 80));
        NEXT_SOUND_TICK.put(id, now + randomRangeTicks(random, 30, 50));
        NEXT_SLIPPERY_TICK.put(id, now + randomRangeTicks(random, 50, 100));

        SanitySystem.forceSync(player);
    }

    public static void onPlayerLogout(ServerPlayer player, MinecraftServer server) {
        UUID id = player.getUUID();
        NEXT_WORLD_EVENT_TICK.remove(id);
        NEXT_WATCHER_TICK.remove(id);
        NEXT_DRAGON_PRANK_TICK.remove(id);
        NEXT_MOB_SWARM_TICK.remove(id);
        NEXT_CURSOR_PRANK_TICK.remove(id);
        NEXT_ITEM_THEFT_TICK.remove(id);
        NEXT_CROUCH_TICK.remove(id);
        NEXT_JUMP_TICK.remove(id);
        NEXT_SOUND_TICK.remove(id);
        NEXT_SLIPPERY_TICK.remove(id);
        HomeMemorySystem.forget(id);
        DragonPrankSystem.forget(id, server);
        MobSwarmPrankSystem.forget(id, server);
    }

    private static void tickPlayer(ServerPlayer player) {
        SanitySystem.tick(player);

        if (player.tickCount % 20 == 0) {
            HomeMemorySystem.tick(player);
        }

        long now = player.serverLevel().getGameTime();
        UUID playerId = player.getUUID();
        RandomSource random = player.getRandom();

        if (now >= NEXT_WORLD_EVENT_TICK.getOrDefault(playerId, now)) {
            PrankBlockPlan blockPlan = triggerWorldEvent(player);
            if (blockPlan != null) {
                LivingWorldNetwork.sendBlockPrank(player, blockPlan.lifetimeTicks(), blockPlan.changes());
                SanitySystem.onStrangeEvent(player, player.level().isNight() ? 3 : 2);
            }
            NEXT_WORLD_EVENT_TICK.put(playerId, now + computeNextWorldEventDelay(player));
        }

        if (now >= NEXT_WATCHER_TICK.getOrDefault(playerId, now)) {
            PrankSpawnPlan watcherPlan = WatcherSystem.create(player, SanitySystem.getSanityNormalized(player));
            if (watcherPlan != null) {
                sendPlanToPlayer(player, watcherPlan);
                SanitySystem.onStrangeEvent(player, 2);
            }
            NEXT_WATCHER_TICK.put(playerId, now + computeNextWatcherDelay(player));
        }

        if (now >= NEXT_DRAGON_PRANK_TICK.getOrDefault(playerId, now)) {
            String result = DragonPrankSystem.trySpawn(player);
            if (result != null) {
                SanitySystem.onStrangeEvent(player, 4);
            }
            NEXT_DRAGON_PRANK_TICK.put(playerId, now + LivingWorldConfig.getDragonPrankIntervalTicks());
        }

        if (now >= NEXT_MOB_SWARM_TICK.getOrDefault(playerId, now)) {
            String result = MobSwarmPrankSystem.trySpawn(player);
            if (result != null) {
                SanitySystem.onStrangeEvent(player, 3);
            }
            NEXT_MOB_SWARM_TICK.put(playerId, now + LivingWorldConfig.getMobSwarmIntervalTicks());
        }

        if (now >= NEXT_CURSOR_PRANK_TICK.getOrDefault(playerId, now)) {
            int duration = 15 * 20;
            LivingWorldNetwork.sendClientAction(player, ClientActionType.HIDE_CURSOR, duration, 0);
            NEXT_CURSOR_PRANK_TICK.put(playerId, now + randomRangeTicks(random, 35, 80));
        }

        if (now >= NEXT_ITEM_THEFT_TICK.getOrDefault(playerId, now)) {
            int slot = pickRandomInventorySlot(player, random);
            if (slot >= 0) {
                int duration = randomRangeTicks(random, 5, 10);
                LivingWorldNetwork.sendClientAction(player, ClientActionType.STEAL_ITEM, duration, slot);
            }
            NEXT_ITEM_THEFT_TICK.put(playerId, now + randomRangeTicks(random, 45, 90));
        }

        if (now >= NEXT_CROUCH_TICK.getOrDefault(playerId, now)) {
            LivingWorldNetwork.sendClientAction(player, ClientActionType.FORCE_CROUCH, 40, 0);
            NEXT_CROUCH_TICK.put(playerId, now + randomRangeTicks(random, 30, 80));
        }

        if (now >= NEXT_JUMP_TICK.getOrDefault(playerId, now)) {
            LivingWorldNetwork.sendClientAction(player, ClientActionType.FORCE_JUMP, 40, 0);
            NEXT_JUMP_TICK.put(playerId, now + randomRangeTicks(random, 30, 80));
        }

        if (now >= NEXT_SOUND_TICK.getOrDefault(playerId, now)) {
            int pick = random.nextInt(3);
            if (pick == 0) {
                LivingWorldNetwork.sendClientAction(player, ClientActionType.SOUND_CREEPER, 0, 0);
            } else if (pick == 1) {
                LivingWorldNetwork.sendClientAction(player, ClientActionType.SOUND_ANVIL, 0, 0);
            } else {
                LivingWorldNetwork.sendClientAction(player, ClientActionType.SOUND_TNT, 0, 0);
            }
            NEXT_SOUND_TICK.put(playerId, now + randomRangeTicks(random, 30, 50));
        }

        if (now >= NEXT_SLIPPERY_TICK.getOrDefault(playerId, now)) {
            int radius = Mth.nextInt(random, 10, 15);
            LivingWorldNetwork.sendClientAction(player, ClientActionType.SLIPPERY_FLOOR, 80, radius);
            NEXT_SLIPPERY_TICK.put(playerId, now + randomRangeTicks(random, 50, 100));
        }
    }

    private static void sendPlanToPlayer(ServerPlayer player, PrankSpawnPlan plan) {
        LivingWorldNetwork.sendPrankSpawns(player, plan.lifetimeTicks(), plan.entries());
    }

    private static PrankBlockPlan triggerWorldEvent(ServerPlayer player) {
        double sanity = SanitySystem.getSanityNormalized(player);

        // Core prank rhythm: frequent off-screen block movement every 10-15 seconds.
        return BlockOdditySystem.trigger(player, sanity);
    }

    private static long computeNextWorldEventDelay(ServerPlayer player) {
        RandomSource random = player.getRandom();
        int min = LivingWorldConfig.getMinEventIntervalTicks();
        int max = LivingWorldConfig.getMaxEventIntervalTicks();
        return Mth.nextInt(random, min, max);
    }

    private static long computeNextWatcherDelay(ServerPlayer player) {
        RandomSource random = player.getRandom();
        double sanity = SanitySystem.getSanityNormalized(player);

        int min = LivingWorldConfig.getMinWatcherIntervalTicks();
        int max = LivingWorldConfig.getMaxWatcherIntervalTicks();
        int base = Mth.nextInt(random, min, max);

        double modifier = 1.0D - sanity * 0.40D;
        if (player.level().isNight()) {
            modifier -= 0.10D;
        }

        int adjusted = (int) (base * Math.max(0.30D, modifier));
        return Math.max(20L, adjusted);
    }

    private static int pickRandomInventorySlot(ServerPlayer player, RandomSource random) {
        List<Integer> filled = new ArrayList<>();
        for (int i = 0; i < player.getInventory().items.size(); i++) {
            if (!player.getInventory().items.get(i).isEmpty()) {
                filled.add(i);
            }
        }

        if (filled.isEmpty()) {
            return -1;
        }

        return filled.get(random.nextInt(filled.size()));
    }

    private static int randomRangeTicks(RandomSource random, int minSeconds, int maxSeconds) {
        int sec = Mth.nextInt(random, minSeconds, maxSeconds);
        return sec * 20;
    }
}
