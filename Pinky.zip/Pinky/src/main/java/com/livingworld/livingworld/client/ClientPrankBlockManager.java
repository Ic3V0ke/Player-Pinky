package com.livingworld.livingworld.client;

import com.livingworld.livingworld.prank.PrankBlockPlan;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class ClientPrankBlockManager {
    private static final List<ActiveBlockPrank> ACTIVE = new ArrayList<>();

    private ClientPrankBlockManager() {
    }

    public static void apply(int lifetimeTicks, List<PrankBlockPlan.BlockChange> changes) {
        Minecraft minecraft = Minecraft.getInstance();
        ClientLevel level = minecraft.level;
        if (level == null || changes.isEmpty()) {
            return;
        }

        long expiry = level.getGameTime() + Math.max(1, lifetimeTicks);

        for (PrankBlockPlan.BlockChange change : changes) {
            BlockState fromState = Block.stateById(change.fromStateId());
            BlockState toState = Block.stateById(change.toStateId());
            level.setBlock(change.pos(), toState, 3);
            ACTIVE.add(new ActiveBlockPrank(change, fromState, expiry));
        }
    }

    public static void tick() {
        Minecraft minecraft = Minecraft.getInstance();
        ClientLevel level = minecraft.level;
        if (level == null || ACTIVE.isEmpty()) {
            return;
        }

        long now = level.getGameTime();
        Iterator<ActiveBlockPrank> iterator = ACTIVE.iterator();
        while (iterator.hasNext()) {
            ActiveBlockPrank prank = iterator.next();
            if (now >= prank.expireTick()) {
                level.setBlock(prank.change().pos(), prank.restoreState(), 3);
                iterator.remove();
            }
        }
    }

    private record ActiveBlockPrank(PrankBlockPlan.BlockChange change, BlockState restoreState, long expireTick) {
    }
}
