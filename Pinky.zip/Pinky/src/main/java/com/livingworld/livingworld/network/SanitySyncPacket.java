package com.livingworld.livingworld.network;

import com.livingworld.livingworld.client.ClientSanityState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record SanitySyncPacket(int sanity, int sanityMax, int recentEventTicks) {
    public static void encode(SanitySyncPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.sanity);
        buffer.writeVarInt(message.sanityMax);
        buffer.writeVarInt(message.recentEventTicks);
    }

    public static SanitySyncPacket decode(FriendlyByteBuf buffer) {
        int sanity = buffer.readVarInt();
        int sanityMax = buffer.readVarInt();
        int recentEventTicks = buffer.readVarInt();
        return new SanitySyncPacket(sanity, sanityMax, recentEventTicks);
    }

    public static void handle(SanitySyncPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                ClientSanityState.update(message.sanity, message.sanityMax, message.recentEventTicks)
        ));
        context.setPacketHandled(true);
    }
}
