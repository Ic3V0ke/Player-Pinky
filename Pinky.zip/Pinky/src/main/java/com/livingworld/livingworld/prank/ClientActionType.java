package com.livingworld.livingworld.prank;

public enum ClientActionType {
    HIDE_CURSOR,
    STEAL_ITEM,
    FORCE_CROUCH,
    FORCE_JUMP,
    SOUND_CREEPER,
    SOUND_ANVIL,
    SOUND_TNT,
    SLIPPERY_FLOOR
}
