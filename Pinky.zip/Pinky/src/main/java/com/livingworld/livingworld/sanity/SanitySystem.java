package com.livingworld.livingworld.sanity;

import com.livingworld.livingworld.LivingWorldConfig;
import com.livingworld.livingworld.network.LivingWorldNetwork;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;

public final class SanitySystem {
    public static final String ROOT_TAG = "livingworld_data";

    private static final String SANITY_KEY = "sanity";
    private static final String RECENT_EVENT_TICKS_KEY = "recent_event_ticks";
    private static final String SYNC_COOLDOWN_KEY = "sync_cooldown";
    private static final String LAST_SYNCED_SANITY_KEY = "last_synced_sanity";

    private SanitySystem() {
    }

    public static void tick(ServerPlayer player) {
        if (player.tickCount % 20 != 0) {
            return;
        }

        CompoundTag data = getOrCreateData(player);
        int sanity = getSanity(player);
        int recentEventTicks = Math.max(0, data.getInt(RECENT_EVENT_TICKS_KEY) - 20);

        int delta = 0;
        if (player.level().isNight()) {
            delta += LivingWorldConfig.SANITY_GAIN_NIGHT.get();
        }

        int localBrightness = player.level().getMaxLocalRawBrightness(player.blockPosition());
        if (localBrightness <= 4) {
            delta += LivingWorldConfig.SANITY_GAIN_DARKNESS.get();
        }

        if (isAlone(player)) {
            delta += LivingWorldConfig.SANITY_GAIN_ALONE.get();
        }

        if (recentEventTicks > 0) {
            delta += LivingWorldConfig.SANITY_GAIN_RECENT_EVENT.get();
        }

        if (!player.level().isNight() && localBrightness >= 10) {
            delta -= LivingWorldConfig.SANITY_DAY_DECAY.get();
        }

        int max = LivingWorldConfig.SANITY_MAX.get();
        sanity = clamp(sanity + delta, 0, max);

        data.putInt(SANITY_KEY, sanity);
        data.putInt(RECENT_EVENT_TICKS_KEY, recentEventTicks);

        int cooldown = data.getInt(SYNC_COOLDOWN_KEY) - 20;
        int lastSynced = data.getInt(LAST_SYNCED_SANITY_KEY);

        if (cooldown <= 0 || lastSynced != sanity) {
            LivingWorldNetwork.sendSanity(player, sanity, max, recentEventTicks);
            data.putInt(SYNC_COOLDOWN_KEY, 40);
            data.putInt(LAST_SYNCED_SANITY_KEY, sanity);
        } else {
            data.putInt(SYNC_COOLDOWN_KEY, cooldown);
        }
    }

    public static void onStrangeEvent(ServerPlayer player, int intensity) {
        CompoundTag data = getOrCreateData(player);
        int current = getSanity(player);
        int increase = Math.max(1, intensity * 2);
        int max = LivingWorldConfig.SANITY_MAX.get();
        int updated = clamp(current + increase, 0, max);

        int eventTicks = data.getInt(RECENT_EVENT_TICKS_KEY);
        int boostedEventTicks = Math.max(eventTicks, 20 * 90);

        data.putInt(SANITY_KEY, updated);
        data.putInt(RECENT_EVENT_TICKS_KEY, boostedEventTicks);
        data.putInt(SYNC_COOLDOWN_KEY, 0);
    }

    public static int getSanity(ServerPlayer player) {
        return clamp(getOrCreateData(player).getInt(SANITY_KEY), 0, LivingWorldConfig.SANITY_MAX.get());
    }

    public static int getRecentEventTicks(ServerPlayer player) {
        return Math.max(0, getOrCreateData(player).getInt(RECENT_EVENT_TICKS_KEY));
    }

    public static double getSanityNormalized(ServerPlayer player) {
        return getSanity(player) / (double) LivingWorldConfig.SANITY_MAX.get();
    }

    public static void forceSync(ServerPlayer player) {
        CompoundTag data = getOrCreateData(player);
        int sanity = getSanity(player);
        int max = LivingWorldConfig.SANITY_MAX.get();
        int recent = getRecentEventTicks(player);

        LivingWorldNetwork.sendSanity(player, sanity, max, recent);
        data.putInt(SYNC_COOLDOWN_KEY, 40);
        data.putInt(LAST_SYNCED_SANITY_KEY, sanity);
    }

    public static void copyPersistentData(ServerPlayer original, ServerPlayer clone) {
        CompoundTag originalData = original.getPersistentData();
        CompoundTag cloneData = clone.getPersistentData();

        if (originalData.contains(ROOT_TAG, Tag.TAG_COMPOUND)) {
            cloneData.put(ROOT_TAG, originalData.getCompound(ROOT_TAG).copy());
        }
    }

    private static CompoundTag getOrCreateData(ServerPlayer player) {
        CompoundTag persistentData = player.getPersistentData();
        if (!persistentData.contains(ROOT_TAG, Tag.TAG_COMPOUND)) {
            persistentData.put(ROOT_TAG, new CompoundTag());
        }
        return persistentData.getCompound(ROOT_TAG);
    }

    private static boolean isAlone(ServerPlayer player) {
        return player.serverLevel().players().stream()
                .noneMatch(other -> other != player && other.distanceToSqr(player) <= 32.0D * 32.0D);
    }

    private static int clamp(int value, int min, int max) {
        return Math.min(max, Math.max(min, value));
    }
}
