package com.livingworld.livingworld.network;

import com.livingworld.livingworld.client.ClientPrankBlockManager;
import com.livingworld.livingworld.prank.PrankBlockPlan;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public record PrankBlockPacket(int lifetimeTicks, List<PrankBlockPlan.BlockChange> changes) {
    public static void encode(PrankBlockPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.lifetimeTicks);
        buffer.writeVarInt(message.changes.size());
        for (PrankBlockPlan.BlockChange change : message.changes) {
            buffer.writeBlockPos(change.pos());
            buffer.writeVarInt(change.fromStateId());
            buffer.writeVarInt(change.toStateId());
        }
    }

    public static PrankBlockPacket decode(FriendlyByteBuf buffer) {
        int lifetimeTicks = buffer.readVarInt();
        int size = buffer.readVarInt();
        List<PrankBlockPlan.BlockChange> changes = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            BlockPos pos = buffer.readBlockPos();
            int fromStateId = buffer.readVarInt();
            int toStateId = buffer.readVarInt();
            changes.add(new PrankBlockPlan.BlockChange(pos, fromStateId, toStateId));
        }
        return new PrankBlockPacket(lifetimeTicks, changes);
    }

    public static void handle(PrankBlockPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                ClientPrankBlockManager.apply(message.lifetimeTicks, message.changes)
        ));
        context.setPacketHandled(true);
    }
}
