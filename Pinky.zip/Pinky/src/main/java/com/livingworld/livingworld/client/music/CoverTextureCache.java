package com.livingworld.livingworld.client.music;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class CoverTextureCache {
    private static final int COVER_SIZE = 256;
    private static final Map<String, ResourceLocation> CACHE = new HashMap<>();

    private CoverTextureCache() {
    }

    public static ResourceLocation getCover(MusicTrack track) {
        if (track == null || track.coverPath() == null) {
            return null;
        }

        String key = cacheKey(track.coverPath());
        ResourceLocation cached = CACHE.get(key);
        if (cached != null) {
            return cached;
        }

        try {
            BufferedImage source = ImageIO.read(track.coverPath().toFile());
            if (source == null) {
                return null;
            }

            BufferedImage resized = cropAndResize(source);
            NativeImage nativeImage = new NativeImage(COVER_SIZE, COVER_SIZE, false);
            for (int y = 0; y < COVER_SIZE; y++) {
                for (int x = 0; x < COVER_SIZE; x++) {
                    nativeImage.setPixelRGBA(x, y, toNativeRgba(resized.getRGB(x, y)));
                }
            }

            DynamicTexture texture = new DynamicTexture(nativeImage);
            ResourceLocation location = Minecraft.getInstance().getTextureManager().register("pinky_cover", texture);
            CACHE.put(key, location);
            return location;
        } catch (IOException | RuntimeException ignored) {
            return null;
        }
    }

    private static BufferedImage cropAndResize(BufferedImage source) {
        int side = Math.min(source.getWidth(), source.getHeight());
        int sourceX = Math.max(0, (source.getWidth() - side) / 2);
        int sourceY = Math.max(0, (source.getHeight() - side) / 2);

        BufferedImage resized = new BufferedImage(COVER_SIZE, COVER_SIZE, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = resized.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics.drawImage(source, 0, 0, COVER_SIZE, COVER_SIZE, sourceX, sourceY, sourceX + side, sourceY + side, null);
        graphics.dispose();
        return resized;
    }

    private static int toNativeRgba(int argb) {
        int alpha = (argb >>> 24) & 255;
        int red = (argb >>> 16) & 255;
        int green = (argb >>> 8) & 255;
        int blue = argb & 255;
        return (alpha << 24) | (blue << 16) | (green << 8) | red;
    }

    private static String cacheKey(Path path) {
        try {
            return path.toRealPath().toString().toLowerCase(Locale.ROOT);
        } catch (IOException ignored) {
            return path.toAbsolutePath().normalize().toString().toLowerCase(Locale.ROOT);
        }
    }
}
