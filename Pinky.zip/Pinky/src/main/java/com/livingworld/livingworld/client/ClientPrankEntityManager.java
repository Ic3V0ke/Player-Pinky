package com.livingworld.livingworld.client;

import com.livingworld.livingworld.prank.PrankSpawnPlan;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

public final class ClientPrankEntityManager {
    private static final AtomicInteger NEXT_ID = new AtomicInteger(Integer.MIN_VALUE / 2);
    private static final Map<Integer, Long> ACTIVE = new HashMap<>();

    private ClientPrankEntityManager() {
    }

    public static void spawn(int lifetimeTicks, List<PrankSpawnPlan.SpawnEntry> entries) {
        Minecraft minecraft = Minecraft.getInstance();
        ClientLevel level = minecraft.level;
        if (level == null || entries.isEmpty()) {
            return;
        }

        long expireTick = level.getGameTime() + Math.max(1, lifetimeTicks);

        for (PrankSpawnPlan.SpawnEntry entry : entries) {
            Entity entity = createEntity(level, entry.entityTypeId());
            if (entity == null) {
                continue;
            }

            int id = NEXT_ID.getAndIncrement();
            entity.setId(id);
            entity.setPos(entry.x(), entry.y(), entry.z());
            entity.setYRot(entry.yRot());
            entity.setYHeadRot(entry.yRot());
            entity.setSilent(true);

            if (entity instanceof Mob mob) {
                mob.setNoAi(true);
            }

            if (entity instanceof LivingEntity livingEntity) {
                livingEntity.setInvulnerable(true);
            }

            if (level.addFreshEntity(entity)) {
                ACTIVE.put(id, expireTick);
            }
        }
    }

    public static void tick() {
        Minecraft minecraft = Minecraft.getInstance();
        ClientLevel level = minecraft.level;
        if (level == null || ACTIVE.isEmpty()) {
            return;
        }

        long now = level.getGameTime();
        ACTIVE.entrySet().removeIf(entry -> {
            int id = entry.getKey();
            long expiry = entry.getValue();

            Entity entity = level.getEntity(id);
            if (entity == null) {
                return true;
            }

            if (now >= expiry) {
                entity.discard();
                return true;
            }

            return false;
        });
    }

    private static Entity createEntity(ClientLevel level, ResourceLocation entityId) {
        Optional<EntityType<?>> optionalType = BuiltInRegistries.ENTITY_TYPE.getOptional(entityId);
        if (optionalType.isEmpty()) {
            return null;
        }

        EntityType<?> type = optionalType.get();
        return type.create(level);
    }
}
