package com.livingworld.livingworld.client.music;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;

public class PinkyMusicScreen extends Screen {
    private static final int COVER_TEXTURE_SIZE = 256;
    private static final int ROW_HEIGHT = 38;
    private static final int COLOR_PANEL = 0xE8171028;
    private static final int COLOR_PANEL_SOFT = 0xCC2D1538;
    private static final int COLOR_PINK = 0xFFFF74B8;
    private static final int COLOR_PINK_LIGHT = 0xFFFFC3DF;
    private static final int COLOR_PINK_HOT = 0xFFFF2F92;
    private static final int COLOR_WHITE = 0xFFFFF7FB;
    private static final int COLOR_MUTED = 0xFFCA9EB8;

    private final List<PinkyButton> buttons = new ArrayList<>();
    private List<MusicTrack> tracks = List.of();
    private int selectedIndex = -1;
    private int age;
    private double scroll;
    private int panelX;
    private int panelY;
    private int panelW;
    private int panelH;
    private int listX;
    private int listY;
    private int listW;
    private int listH;
    private int closingTicks;
    private boolean closing;
    private boolean draggingVolume;
    private int volumeSliderX;
    private int volumeSliderY;
    private int volumeSliderW;
    private int volumeSliderH;
    private int progressX;
    private int progressY;
    private int progressW;

    public PinkyMusicScreen() {
        super(Component.literal("Pinky Player"));
    }

    @Override
    protected void init() {
        reloadTracks();
        calculateLayout(1.0F);
    }

    @Override
    public void tick() {
        if (closing) {
            closingTicks++;
            if (closingTicks >= 10) {
                Minecraft.getInstance().setScreen(null);
            }
            return;
        }
        age++;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        float open = easeOutCubic(Mth.clamp((age + partialTick) / 14.0F, 0.0F, 1.0F));
        float close = closing ? easeInCubic(Mth.clamp((closingTicks + partialTick) / 10.0F, 0.0F, 1.0F)) : 0.0F;
        float visibility = Mth.clamp(open * (1.0F - close), 0.0F, 1.0F);
        calculateLayout(visibility);

        renderAnimatedBackdrop(graphics, partialTick, visibility);
        drawSoftPanel(graphics, panelX, panelY, panelW, panelH, alpha(Math.round(235 * visibility), 0x171028), alpha(Math.round(215 * visibility), 0x3B183F));
        renderHeader(graphics, visibility);
        renderCoverColumn(graphics, mouseX, mouseY, partialTick);
        renderTrackList(graphics, mouseX, mouseY, partialTick);
        renderControls(graphics, mouseX, mouseY);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (closing) {
            return true;
        }
        if (button == 0) {
            if (isInsideVolumeSlider(mouseX, mouseY)) {
                draggingVolume = true;
                updateVolumeFromMouse(mouseX);
                playButtonSound();
                return true;
            }

            for (PinkyButton pinkyButton : buttons) {
                if (pinkyButton.mouseClicked(mouseX, mouseY)) {
                    playButtonSound();
                    return true;
                }
            }

            if (mouseX >= listX && mouseX <= listX + listW && mouseY >= listY && mouseY <= listY + listH) {
                int index = (int) ((mouseY - listY + scroll) / ROW_HEIGHT);
                if (index >= 0 && index < tracks.size()) {
                    selectedIndex = index;
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (draggingVolume) {
            updateVolumeFromMouse(mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggingVolume) {
            draggingVolume = false;
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (mouseX >= listX && mouseX <= listX + listW && mouseY >= listY && mouseY <= listY + listH) {
            scroll = Mth.clamp(scroll - delta * ROW_HEIGHT * 0.85D, 0.0D, maxScroll());
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (PinkyKeyMappings.OPEN_PLAYER.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_SPACE || keyCode == GLFW.GLFW_KEY_ENTER) {
            playOrPauseSelected();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_UP) {
            selectOffset(-1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_DOWN) {
            selectOffset(1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_LEFT) {
            previousTrack();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT) {
            nextTrack();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        if (!closing) {
            closing = true;
            closingTicks = 0;
        }
    }

    private void reloadTracks() {
        tracks = MusicLibrary.scanTracks();
        if (tracks.isEmpty()) {
            selectedIndex = -1;
            scroll = 0.0D;
            return;
        }

        MusicTrack currentTrack = MusicPlaybackEngine.getCurrentTrack();
        selectedIndex = currentTrack == null ? Mth.clamp(selectedIndex, 0, tracks.size() - 1) : indexOfTrack(currentTrack);
        if (selectedIndex < 0) {
            selectedIndex = 0;
        }
        scroll = Mth.clamp(scroll, 0.0D, maxScroll());
    }

    private void calculateLayout(float open) {
        panelW = Math.min(690, Math.max(380, Math.min(width - 80, width * 82 / 100)));
        panelH = Math.min(430, Math.max(330, Math.min(height - 58, height * 82 / 100)));
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2 + Math.round((1.0F - open) * 18.0F);

        int leftW = Math.min(264, Math.max(224, panelW * 37 / 100));
        listX = panelX + leftW + 20;
        listY = panelY + 78;
        listW = Math.max(120, panelX + panelW - listX - 24);
        listH = Math.max(96, panelY + panelH - listY - 28);

        ensureButtons();
        int controlsX = panelX + 28;
        int controlsY = panelY + panelH - 98;
        int buttonH = 22;
        int gap = 7;
        int halfW = (leftW - 28 - gap) / 2;
        buttons.get(0).setBounds(controlsX, controlsY, halfW, buttonH);
        buttons.get(1).setBounds(controlsX + halfW + gap, controlsY, halfW, buttonH);
        buttons.get(2).setBounds(controlsX, controlsY + 28, halfW, buttonH);
        buttons.get(3).setBounds(controlsX + halfW + gap, controlsY + 28, halfW, buttonH);
        buttons.get(4).setBounds(controlsX, controlsY + 56, leftW - 28, buttonH);
        buttons.get(5).setBounds(0, 0, 0, 0);
        buttons.get(6).setBounds(0, 0, 0, 0);

        progressX = controlsX;
        progressY = panelY + panelH - 154;
        progressW = leftW - 28;
        volumeSliderX = controlsX;
        volumeSliderY = panelY + panelH - 117;
        volumeSliderW = leftW - 28;
        volumeSliderH = 12;
    }

    private void ensureButtons() {
        if (!buttons.isEmpty()) {
            return;
        }
        buttons.add(new PinkyButton(0, 0, 0, 0, this::playLabel, this::playOrPauseSelected));
        buttons.add(new PinkyButton(0, 0, 0, 0, () -> "STOP", MusicPlaybackEngine::stop));
        buttons.add(new PinkyButton(0, 0, 0, 0, () -> "PREV", this::previousTrack));
        buttons.add(new PinkyButton(0, 0, 0, 0, () -> "NEXT", this::nextTrack));
        buttons.add(new PinkyButton(0, 0, 0, 0, () -> "REFRESH", this::reloadTracks));
        buttons.add(new PinkyButton(0, 0, 0, 0, () -> "", () -> changeVolume(-0.08F)));
        buttons.add(new PinkyButton(0, 0, 0, 0, () -> "", () -> changeVolume(0.08F)));
    }

    private void renderAnimatedBackdrop(GuiGraphics graphics, float partialTick, float open) {
        graphics.fillGradient(0, 0, width, height, alpha(Math.round(190 * open), 0x170B1D), alpha(Math.round(220 * open), 0x40122E));
        graphics.fillGradient(0, 0, width, height / 2, alpha(Math.round(95 * open), 0xFF7EBE), alpha(0, 0xFF7EBE));

        for (int i = 0; i < 34; i++) {
            float seed = i * 37.37F;
            float drift = (age + partialTick) * (0.25F + (i % 5) * 0.05F);
            int x = Math.floorMod((int) (seed * 19.0F + drift * (i % 2 == 0 ? 1.0F : -1.0F)), Math.max(1, width + 60)) - 30;
            int y = Math.floorMod((int) (seed * 11.0F + drift * 2.0F), Math.max(1, height + 70)) - 35;
            int size = 2 + i % 5;
            int color = alpha(Math.round((42 + (i % 4) * 18) * open), i % 3 == 0 ? 0xFFC2E2 : 0xFF6BAD);
            graphics.fill(x, y + size / 2, x + size, y + size / 2 + 1, color);
            graphics.fill(x + size / 2, y, x + size / 2 + 1, y + size, color);
        }
    }

    private void renderHeader(GuiGraphics graphics, float open) {
        int titleX = panelX + 28;
        int titleY = panelY + 22;
        float wave = (float) Math.sin((age + open * 8.0F) * 0.12F);

        graphics.drawString(font, "Pinky Player", titleX + 1, titleY + 1, alpha(140, 0x000000), false);
        graphics.drawString(font, "Pinky Player", titleX, titleY, COLOR_WHITE, false);
        graphics.drawString(font, "soft pink radio / local music", titleX, titleY + 14, COLOR_MUTED, false);

        int pillW = 132;
        int pillX = panelX + panelW - pillW - 24;
        int pillY = panelY + 24 + Math.round(wave * 2.0F);
        drawCapsule(graphics, pillX, pillY, pillW, 22, alpha(160, 0x4A1636), alpha(220, 0xFF74B8));
        String status = MusicPlaybackEngine.getStatus();
        graphics.drawCenteredString(font, trim(status, pillW - 18), pillX + pillW / 2, pillY + 7, COLOR_PINK_LIGHT);
    }

    private void renderCoverColumn(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        int leftX = panelX + 28;
        int leftW = listX - leftX - 22;
        MusicTrack selected = selectedTrack();
        int coverSize = Math.min(136, Math.max(108, Math.min(leftW - 76, panelH - 286)));
        int coverX = leftX + (leftW - coverSize) / 2;
        int coverY = panelY + 76;
        float pulse = 0.5F + 0.5F * (float) Math.sin((age + partialTick) * 0.12F);

        drawGlowSquare(graphics, coverX - 10, coverY - 10, coverSize + 20, alpha(40 + Math.round(pulse * 55.0F), 0xFF5DA8));
        drawSoftPanel(graphics, coverX - 6, coverY - 6, coverSize + 12, coverSize + 12, alpha(160, 0x33172F), alpha(180, 0xFF74B8));

        ResourceLocation cover = CoverTextureCache.getCover(selected);
        if (cover != null) {
            graphics.blit(cover, coverX, coverY, 0.0F, 0.0F, coverSize, coverSize, COVER_TEXTURE_SIZE, COVER_TEXTURE_SIZE);
            graphics.fill(coverX, coverY + coverSize - 26, coverX + coverSize, coverY + coverSize, alpha(110, 0x000000));
        } else {
            renderFallbackCover(graphics, coverX, coverY, coverSize, pulse);
        }

        renderEqualizer(graphics, coverX + 12, coverY + coverSize - 20, coverSize - 24, 12, partialTick);

        int metaY = coverY + coverSize + 12;
        if (selected == null) {
            graphics.drawCenteredString(font, "No tracks found", leftX + leftW / 2, metaY, COLOR_WHITE);
            graphics.drawCenteredString(font, "Drop mp3/flac into /music", leftX + leftW / 2, metaY + 14, COLOR_MUTED);
        } else {
            graphics.drawCenteredString(font, trim(selected.title(), leftW - 8), leftX + leftW / 2, metaY, COLOR_WHITE);
            graphics.drawCenteredString(font, trim(selected.artist(), leftW - 8), leftX + leftW / 2, metaY + 14, COLOR_MUTED);
            graphics.drawCenteredString(font, selected.extension().toUpperCase(Locale.ROOT), leftX + leftW / 2, metaY + 28, alpha(225, 0xFFC3DF));
        }

        renderProgress(graphics, progressX, progressY, progressW);
        renderVolumeSlider(graphics, mouseX, mouseY);
    }

    private void renderTrackList(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        drawSoftPanel(graphics, listX - 7, listY - 30, listW + 14, listH + 37, COLOR_PANEL_SOFT, alpha(150, 0xFF8AC2));
        graphics.drawString(font, "Library", listX, listY - 21, COLOR_WHITE, false);
        graphics.drawString(font, tracks.size() + " local tracks", listX + listW - font.width(tracks.size() + " local tracks"), listY - 21, COLOR_MUTED, false);

        graphics.enableScissor(listX, listY, listX + listW, listY + listH);
        for (int i = 0; i < tracks.size(); i++) {
            int rowY = listY + i * ROW_HEIGHT - (int) scroll;
            if (rowY > listY + listH || rowY + ROW_HEIGHT < listY) {
                continue;
            }

            float stagger = easeOutCubic(Mth.clamp((age + partialTick - i * 1.35F) / 18.0F, 0.0F, 1.0F));
            int animatedX = listX + Math.round((1.0F - stagger) * 28.0F);
            renderTrackRow(graphics, tracks.get(i), i, animatedX, rowY, mouseX, mouseY, partialTick);
        }
        graphics.disableScissor();
    }

    private void renderTrackRow(GuiGraphics graphics, MusicTrack track, int index, int x, int y, int mouseX, int mouseY, float partialTick) {
        boolean selected = index == selectedIndex;
        boolean hovered = mouseX >= listX && mouseX <= listX + listW && mouseY >= y && mouseY <= y + ROW_HEIGHT;
        boolean active = MusicPlaybackEngine.isActive(track);

        int rowColor = selected ? alpha(190, 0x7D2556) : hovered ? alpha(135, 0x4D1A39) : alpha(72, 0x27172F);
        int borderColor = active ? alpha(240, 0xFF74B8) : selected ? alpha(210, 0xFFC3DF) : alpha(80, 0xFF9DCC);
        drawSoftPanel(graphics, x, y + 3, listW, ROW_HEIGHT - 6, rowColor, borderColor);

        int noteX = x + 10;
        int noteY = y + 14 + (int) Math.round(Math.sin((age + partialTick + index * 4.0F) * 0.16F) * 2.0F);
        graphics.fill(noteX, noteY, noteX + 6, noteY + 12, active ? COLOR_PINK_LIGHT : COLOR_PINK);
        graphics.fill(noteX + 6, noteY + 1, noteX + 13, noteY + 4, active ? COLOR_PINK_LIGHT : COLOR_PINK);
        graphics.fill(noteX + 10, noteY + 10, noteX + 17, noteY + 14, active ? COLOR_PINK_LIGHT : COLOR_PINK);

        int textX = x + 34;
        int maxTextW = listW - 90;
        graphics.drawString(font, trim(track.title(), maxTextW), textX, y + 10, selected ? COLOR_WHITE : alpha(235, 0xFFF7FB), false);
        graphics.drawString(font, trim(track.artist(), maxTextW), textX, y + 24, selected ? COLOR_PINK_LIGHT : COLOR_MUTED, false);

        if (active) {
            String tag = MusicPlaybackEngine.getState() == MusicPlaybackEngine.PlaybackState.PAUSED ? "PAUSE" : "LIVE";
            int tagW = font.width(tag) + 14;
            drawCapsule(graphics, x + listW - tagW - 9, y + 13, tagW, 17, alpha(130, 0xFF2F92), alpha(220, 0xFFC3DF));
            graphics.drawCenteredString(font, tag, x + listW - tagW / 2 - 9, y + 18, COLOR_WHITE);
        }
    }

    private void renderControls(GuiGraphics graphics, int mouseX, int mouseY) {
        for (PinkyButton button : buttons) {
            button.render(graphics, mouseX, mouseY);
        }
    }

    private void renderProgress(GuiGraphics graphics, int x, int y, int width) {
        MusicTrack selected = selectedTrack();
        boolean active = MusicPlaybackEngine.isActive(selected);
        double duration = active ? MusicPlaybackEngine.getDurationSeconds() : 0.0D;
        double progress = active ? MusicPlaybackEngine.getProgressSeconds() : 0.0D;
        float ratio = duration > 0.0D ? Mth.clamp((float) (progress / duration), 0.0F, 1.0F) : 0.0F;

        graphics.drawString(font, active ? MusicPlaybackEngine.formatTime(progress) : "0:00", x, y - 11, COLOR_MUTED, false);
        String durationText = duration > 0.0D ? MusicPlaybackEngine.formatTime(duration) : "--:--";
        graphics.drawString(font, durationText, x + width - font.width(durationText), y - 11, COLOR_MUTED, false);

        drawSoftPanel(graphics, x, y, width, 13, alpha(130, 0x211425), alpha(90, 0xFF74B8));
        int fillW = Math.max(0, Math.round((width - 4) * ratio));
        if (fillW > 0) {
            graphics.fillGradient(x + 2, y + 2, x + 2 + fillW, y + 11, alpha(240, 0xFF2F92), alpha(240, 0xFFC3DF));
            int shimmerX = x + 2 + Math.floorMod(age * 3, Math.max(1, width));
            graphics.fill(shimmerX, y + 2, Math.min(shimmerX + 4, x + width - 2), y + 11, alpha(130, 0xFFFFFF));
        }

        graphics.drawCenteredString(font, "Weather audio", x + width / 2, y + 17, COLOR_MUTED);
    }

    private void renderVolumeSlider(GuiGraphics graphics, int mouseX, int mouseY) {
        boolean hovered = isInsideVolumeSlider(mouseX, mouseY);
        float volume = MusicPlaybackEngine.getPlayerVolume();
        int knobX = volumeSliderX + Math.round(volumeSliderW * volume);
        int glow = hovered || draggingVolume ? 70 : 34;

        graphics.drawString(font, "VOL", volumeSliderX, volumeSliderY - 10, COLOR_MUTED, false);
        String percent = Math.round(volume * 100.0F) + "%";
        graphics.drawString(font, percent, volumeSliderX + volumeSliderW - font.width(percent), volumeSliderY - 10, COLOR_MUTED, false);
        drawSoftPanel(graphics, volumeSliderX, volumeSliderY, volumeSliderW, volumeSliderH, alpha(145, 0x211425), alpha(95 + glow, 0xFF74B8));

        int fillW = Math.max(2, knobX - volumeSliderX);
        graphics.fillGradient(volumeSliderX + 2, volumeSliderY + 3, volumeSliderX + fillW, volumeSliderY + volumeSliderH - 3, alpha(235, 0xFF2F92), alpha(235, 0xFFC3DF));
        graphics.fill(knobX - 3, volumeSliderY - 2, knobX + 3, volumeSliderY + volumeSliderH + 2, alpha(220, 0xFFC3DF));
        graphics.fill(knobX - 1, volumeSliderY - 4, knobX + 1, volumeSliderY + volumeSliderH + 4, COLOR_WHITE);
    }

    private void renderEqualizer(GuiGraphics graphics, int x, int y, int width, int height, float partialTick) {
        int bars = Math.max(8, width / 8);
        int gap = 3;
        int barW = Math.max(2, (width - (bars - 1) * gap) / bars);
        boolean moving = MusicPlaybackEngine.getState() == MusicPlaybackEngine.PlaybackState.PLAYING;

        for (int i = 0; i < bars; i++) {
            float phase = (age + partialTick) * (0.18F + i * 0.006F) + i * 0.73F;
            float value = moving ? 0.25F + 0.75F * (0.5F + 0.5F * (float) Math.sin(phase)) : 0.18F;
            int barH = Math.max(2, Math.round(height * value));
            int barX = x + i * (barW + gap);
            graphics.fill(barX, y + height - barH, barX + barW, y + height, alpha(210, i % 2 == 0 ? 0xFFC3DF : 0xFF74B8));
        }
    }

    private void renderFallbackCover(GuiGraphics graphics, int x, int y, int size, float pulse) {
        graphics.fillGradient(x, y, x + size, y + size, alpha(255, 0xFF74B8), alpha(255, 0x30112F));
        int inset = Math.round(size * (0.16F + pulse * 0.02F));
        graphics.fill(x + inset, y + inset, x + size - inset, y + size - inset, alpha(120, 0xFFFFFF));
        int inner = inset + Math.round(size * 0.14F);
        graphics.fill(x + inner, y + inner, x + size - inner, y + size - inner, alpha(185, 0x1C1024));
        graphics.drawCenteredString(font, "PINKY", x + size / 2, y + size / 2 - 4, COLOR_WHITE);
    }

    private void drawSoftPanel(GuiGraphics graphics, int x, int y, int w, int h, int fillColor, int borderColor) {
        graphics.fill(x + 4, y, x + w - 4, y + h, fillColor);
        graphics.fill(x, y + 4, x + w, y + h - 4, fillColor);
        graphics.fill(x + 4, y + 1, x + w - 4, y + 2, borderColor);
        graphics.fill(x + 4, y + h - 2, x + w - 4, y + h - 1, alpha(120, borderColor));
        graphics.fill(x + 1, y + 4, x + 2, y + h - 4, alpha(115, borderColor));
        graphics.fill(x + w - 2, y + 4, x + w - 1, y + h - 4, alpha(115, borderColor));
    }

    private void drawGlowSquare(GuiGraphics graphics, int x, int y, int size, int color) {
        graphics.fill(x + 10, y, x + size - 10, y + size, alpha(60, color));
        graphics.fill(x, y + 10, x + size, y + size - 10, color);
        graphics.fill(x + 18, y + 18, x + size - 18, y + size - 18, alpha(70, 0xFFFFFF));
    }

    private void drawCapsule(GuiGraphics graphics, int x, int y, int w, int h, int fillColor, int borderColor) {
        graphics.fill(x + h / 2, y, x + w - h / 2, y + h, fillColor);
        graphics.fill(x, y + 3, x + w, y + h - 3, fillColor);
        graphics.fill(x + h / 2, y, x + w - h / 2, y + 1, borderColor);
        graphics.fill(x + h / 2, y + h - 1, x + w - h / 2, y + h, alpha(120, borderColor));
    }

    private void playOrPauseSelected() {
        MusicTrack selected = selectedTrack();
        if (selected == null) {
            return;
        }

        if (MusicPlaybackEngine.isActive(selected)) {
            MusicPlaybackEngine.togglePause();
        } else {
            MusicPlaybackEngine.play(selected);
        }
    }

    private String playLabel() {
        MusicTrack selected = selectedTrack();
        if (MusicPlaybackEngine.isPlaying(selected)) {
            return "PAUSE";
        }
        if (MusicPlaybackEngine.isPaused(selected)) {
            return "RESUME";
        }
        return "PLAY";
    }

    private void previousTrack() {
        if (tracks.isEmpty()) {
            return;
        }
        selectedIndex = Math.floorMod(selectedIndex - 1, tracks.size());
        ensureSelectedVisible();
        MusicPlaybackEngine.play(selectedTrack());
    }

    private void nextTrack() {
        if (tracks.isEmpty()) {
            return;
        }
        selectedIndex = Math.floorMod(selectedIndex + 1, tracks.size());
        ensureSelectedVisible();
        MusicPlaybackEngine.play(selectedTrack());
    }

    private void selectOffset(int offset) {
        if (tracks.isEmpty()) {
            return;
        }
        selectedIndex = Mth.clamp(selectedIndex + offset, 0, tracks.size() - 1);
        ensureSelectedVisible();
    }

    private void ensureSelectedVisible() {
        if (selectedIndex < 0) {
            return;
        }
        int rowTop = selectedIndex * ROW_HEIGHT;
        int rowBottom = rowTop + ROW_HEIGHT;
        if (rowTop < scroll) {
            scroll = rowTop;
        } else if (rowBottom > scroll + listH) {
            scroll = rowBottom - listH;
        }
        scroll = Mth.clamp(scroll, 0.0D, maxScroll());
    }

    private void changeVolume(float amount) {
        MusicPlaybackEngine.setPlayerVolume(MusicPlaybackEngine.getPlayerVolume() + amount);
    }

    private boolean isInsideVolumeSlider(double mouseX, double mouseY) {
        return mouseX >= volumeSliderX - 4 && mouseX <= volumeSliderX + volumeSliderW + 4
                && mouseY >= volumeSliderY - 8 && mouseY <= volumeSliderY + volumeSliderH + 8;
    }

    private void updateVolumeFromMouse(double mouseX) {
        if (volumeSliderW <= 0) {
            return;
        }
        float ratio = (float) ((mouseX - volumeSliderX) / volumeSliderW);
        MusicPlaybackEngine.setPlayerVolume(Mth.clamp(ratio, 0.0F, 1.0F));
    }

    private MusicTrack selectedTrack() {
        if (selectedIndex < 0 || selectedIndex >= tracks.size()) {
            return null;
        }
        return tracks.get(selectedIndex);
    }

    private int indexOfTrack(MusicTrack track) {
        for (int i = 0; i < tracks.size(); i++) {
            if (tracks.get(i).audioPath().equals(track.audioPath())) {
                return i;
            }
        }
        return -1;
    }

    private double maxScroll() {
        return Math.max(0.0D, tracks.size() * ROW_HEIGHT - listH);
    }

    private String trim(String text, int maxWidth) {
        if (text == null) {
            return "";
        }
        if (font.width(text) <= maxWidth) {
            return text;
        }
        String suffix = "...";
        int suffixWidth = font.width(suffix);
        String trimmed = text;
        while (!trimmed.isEmpty() && font.width(trimmed) + suffixWidth > maxWidth) {
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }
        return trimmed + suffix;
    }

    private static float easeOutCubic(float value) {
        float clamped = Mth.clamp(value, 0.0F, 1.0F);
        float inverse = 1.0F - clamped;
        return 1.0F - inverse * inverse * inverse;
    }

    private static float easeInCubic(float value) {
        float clamped = Mth.clamp(value, 0.0F, 1.0F);
        return clamped * clamped * clamped;
    }

    private static int alpha(int alpha, int rgb) {
        return (Mth.clamp(alpha, 0, 255) << 24) | (rgb & 0x00FFFFFF);
    }

    private void playButtonSound() {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.15F, 0.7F));
    }

    private final class PinkyButton {
        private final Supplier<String> label;
        private final Runnable action;
        private int x;
        private int y;
        private int w;
        private int h;
        private float hover;

        private PinkyButton(int x, int y, int w, int h, Supplier<String> label, Runnable action) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.label = label;
            this.action = action;
        }

        private void setBounds(int x, int y, int w, int h) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }

        private void render(GuiGraphics graphics, int mouseX, int mouseY) {
            if (w <= 0 || h <= 0) {
                return;
            }
            boolean inside = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
            hover = Mth.lerp(0.22F, hover, inside ? 1.0F : 0.0F);
            int lift = Math.round(hover * 2.0F);
            int glow = Math.round(hover * 58.0F);

            graphics.fill(x - 3, y - lift - 3, x + w + 3, y + h - lift + 3, alpha(16 + glow, 0xFF74B8));
            graphics.fill(x - 1, y - lift - 1, x + w + 1, y + h - lift + 1, alpha(35 + glow, 0xFFC3DF));
            graphics.fillGradient(x, y - lift, x + w, y + h - lift, alpha(230, inside ? 0xFF5BAE : 0xAE2A76), alpha(230, inside ? 0xFFC3DF : 0xFF74B8));
            graphics.fill(x + 2, y + 2 - lift, x + w - 2, y + h / 2 - lift, alpha(50 + glow, 0xFFFFFF));
            graphics.fill(x, y - lift, x + w, y + 1 - lift, alpha(225, 0xFFC3DF));
            graphics.fill(x, y + h - 1 - lift, x + w, y + h - lift, alpha(170, 0x5D123E));

            String text = label.get();
            graphics.drawCenteredString(font, text, x + w / 2, y + (h - 8) / 2 - lift, COLOR_WHITE);
        }

        private boolean mouseClicked(double mouseX, double mouseY) {
            if (w <= 0 || h <= 0) {
                return false;
            }
            if (mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h) {
                action.run();
                return true;
            }
            return false;
        }
    }
}
