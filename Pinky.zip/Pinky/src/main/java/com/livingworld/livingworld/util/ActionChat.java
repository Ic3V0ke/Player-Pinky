package com.livingworld.livingworld.util;

import com.livingworld.livingworld.LivingWorldConfig;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class ActionChat {
    private ActionChat() {
    }

    public static void send(ServerPlayer player, String text) {
        if (!LivingWorldConfig.DEBUG_CHAT_ACTIONS.get()) {
            return;
        }

        player.sendSystemMessage(Component.literal("[Pinky] " + text));
    }
}
