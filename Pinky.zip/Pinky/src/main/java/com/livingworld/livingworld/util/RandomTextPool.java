package com.livingworld.livingworld.util;

import net.minecraft.util.RandomSource;

public final class RandomTextPool {
    private static final String[] WHISPERS = {
            "Something moved behind you.",
            "The room is different.",
            "Do not look too quickly.",
            "The world blinked first.",
            "You were watched.",
            "This place remembers you."
    };

    private RandomTextPool() {
    }

    public static String randomWhisper(RandomSource random) {
        return WHISPERS[random.nextInt(WHISPERS.length)];
    }
}
