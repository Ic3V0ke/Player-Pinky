package com.livingworld.livingworld.network;

import com.livingworld.livingworld.LivingWorldMod;
import com.livingworld.livingworld.prank.ClientActionType;
import com.livingworld.livingworld.prank.PrankBlockPlan;
import com.livingworld.livingworld.prank.PrankSpawnPlan;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.List;

public final class LivingWorldNetwork {
    private static final String PROTOCOL_VERSION = "1";
    private static int packetId = 0;

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(LivingWorldMod.MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private LivingWorldNetwork() {
    }

    public static void register() {
        CHANNEL.registerMessage(
                packetId++,
                SanitySyncPacket.class,
                SanitySyncPacket::encode,
                SanitySyncPacket::decode,
                SanitySyncPacket::handle
        );

        CHANNEL.registerMessage(
                packetId++,
                PrankSpawnPacket.class,
                PrankSpawnPacket::encode,
                PrankSpawnPacket::decode,
                PrankSpawnPacket::handle
        );

        CHANNEL.registerMessage(
                packetId++,
                PrankBlockPacket.class,
                PrankBlockPacket::encode,
                PrankBlockPacket::decode,
                PrankBlockPacket::handle
        );

        CHANNEL.registerMessage(
                packetId++,
                ClientActionPacket.class,
                ClientActionPacket::encode,
                ClientActionPacket::decode,
                ClientActionPacket::handle
        );
    }

    public static void sendSanity(ServerPlayer player, int sanity, int sanityMax, int recentEventTicks) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new SanitySyncPacket(sanity, sanityMax, recentEventTicks));
    }

    public static void sendPrankSpawns(ServerPlayer player, int lifetimeTicks, List<PrankSpawnPlan.SpawnEntry> entries) {
        if (entries.isEmpty()) {
            return;
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new PrankSpawnPacket(lifetimeTicks, entries));
    }

    public static void sendBlockPrank(ServerPlayer player, int lifetimeTicks, List<PrankBlockPlan.BlockChange> changes) {
        if (changes.isEmpty()) {
            return;
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new PrankBlockPacket(lifetimeTicks, changes));
    }

    public static void sendClientAction(ServerPlayer player, ClientActionType type, int durationTicks, int value) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new ClientActionPacket(type, durationTicks, value));
    }
}
