package com.livingworld.livingworld.world;

import com.livingworld.livingworld.LivingWorldConfig;
import com.livingworld.livingworld.home.HomeMemorySystem;
import com.livingworld.livingworld.util.WorldSightUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.StandingSignBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

public final class NightEventSystem {
    private static final Block[] PATH_BLOCKS = new Block[]{Blocks.COARSE_DIRT, Blocks.GRAVEL, Blocks.COBBLESTONE, Blocks.MOSSY_COBBLESTONE};

    private NightEventSystem() {
    }

    public static String trigger(ServerPlayer player, double sanityFactor) {
        if (!player.level().isNight()) {
            return null;
        }

        ServerLevel level = player.serverLevel();
        RandomSource random = level.random;

        for (int i = 0; i < 6; i++) {
            int action = random.nextInt(5);
            String result;

            switch (action) {
                case 0 -> result = mutateTree(level, player, random);
                case 1 -> result = makeStrangePath(level, player, random);
                case 2 -> result = replaceHomeBlock(level, player, random);
                case 3 -> result = placeNightSign(level, player, random);
                default -> result = placeRedTorch(level, player, random);
            }

            if (result != null) {
                return result;
            }
        }

        // High sanity strongly favors additional strange structures at night.
        if (sanityFactor > 0.65D) {
            String extraPath = makeStrangePath(level, player, random);
            if (extraPath != null) {
                return extraPath;
            }
            return placeRedTorch(level, player, random);
        }

        return null;
    }

    private static String mutateTree(ServerLevel level, ServerPlayer player, RandomSource random) {
        int radius = LivingWorldConfig.EVENT_RADIUS.get() + 8;

        for (int i = 0; i < 120; i++) {
            BlockPos pos = randomAround(player.blockPosition(), random, radius, 8);
            BlockState state = level.getBlockState(pos);
            if (!state.is(BlockTags.LOGS) && !state.is(BlockTags.LEAVES)) {
                continue;
            }

            if (WorldSightUtil.isBlockObserved(player, pos, 45.0D)) {
                continue;
            }

            Block replacement = state.is(BlockTags.LOGS) ? Blocks.STRIPPED_DARK_OAK_LOG : Blocks.AZALEA_LEAVES;
            level.setBlock(pos, replacement.defaultBlockState(), Block.UPDATE_ALL);
            return "A tree changed at night: " + formatPos(pos) + ".";
        }

        return null;
    }

    private static String makeStrangePath(ServerLevel level, ServerPlayer player, RandomSource random) {
        BlockPos origin = randomAround(player.blockPosition(), random, LivingWorldConfig.EVENT_RADIUS.get() + 6, 2);
        if (WorldSightUtil.isBlockObserved(player, origin, 50.0D)) {
            return null;
        }

        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos(origin.getX(), origin.getY(), origin.getZ());
        int length = 4 + random.nextInt(4);
        int dirX = random.nextBoolean() ? 1 : -1;
        int dirZ = random.nextBoolean() ? 1 : -1;

        boolean changedAny = false;
        for (int i = 0; i < length; i++) {
            int topY = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cursor.getX(), cursor.getZ());
            BlockPos groundPos = new BlockPos(cursor.getX(), topY - 1, cursor.getZ());
            if (!WorldSightUtil.isBlockObserved(player, groundPos, 50.0D) && !level.getBlockState(groundPos).isAir()) {
                Block replacement = PATH_BLOCKS[random.nextInt(PATH_BLOCKS.length)];
                level.setBlock(groundPos, replacement.defaultBlockState(), Block.UPDATE_ALL);
                changedAny = true;
            }

            cursor.set(cursor.getX() + dirX, cursor.getY(), cursor.getZ() + dirZ);
            if (random.nextFloat() < 0.4F) {
                dirX = random.nextBoolean() ? 1 : -1;
            }
            if (random.nextFloat() < 0.4F) {
                dirZ = random.nextBoolean() ? 1 : -1;
            }
        }

        return changedAny ? "A strange path appeared near " + formatPos(origin) + "." : null;
    }

    private static String replaceHomeBlock(ServerLevel level, ServerPlayer player, RandomSource random) {
        BlockPos anchor = HomeMemorySystem.getAnchor(player);

        for (int i = 0; i < 80; i++) {
            BlockPos pos = randomAround(anchor, random, 10, 5);
            BlockState state = level.getBlockState(pos);
            if (state.isAir() || state.hasBlockEntity() || state.is(Blocks.BEDROCK)) {
                continue;
            }

            if (WorldSightUtil.isBlockObserved(player, pos, 45.0D)) {
                continue;
            }

            Block replacement = random.nextBoolean() ? Blocks.DEEPSLATE_BRICKS : Blocks.CRACKED_STONE_BRICKS;
            level.setBlock(pos, replacement.defaultBlockState(), Block.UPDATE_ALL);
            return "One house block was replaced at " + formatPos(pos) + ".";
        }

        return null;
    }

    private static String placeNightSign(ServerLevel level, ServerPlayer player, RandomSource random) {
        int radius = LivingWorldConfig.EVENT_RADIUS.get() + 4;

        for (int i = 0; i < 50; i++) {
            int x = player.getBlockX() + random.nextInt(radius * 2 + 1) - radius;
            int z = player.getBlockZ() + random.nextInt(radius * 2 + 1) - radius;
            int y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos signPos = new BlockPos(x, y, z);

            if (!level.isEmptyBlock(signPos) || level.getBlockState(signPos.below()).isAir()) {
                continue;
            }

            if (WorldSightUtil.isBlockObserved(player, signPos, 50.0D)) {
                continue;
            }

            BlockState signState = Blocks.OAK_SIGN.defaultBlockState();
            if (signState.getBlock() instanceof StandingSignBlock && signState.hasProperty(StandingSignBlock.ROTATION)) {
                signState = signState.setValue(StandingSignBlock.ROTATION, random.nextInt(16));
            }

            level.setBlock(signPos, signState, Block.UPDATE_ALL);
            BlockEntity blockEntity = level.getBlockEntity(signPos);
            if (blockEntity instanceof SignBlockEntity signBlockEntity) {
                List<? extends String> texts = LivingWorldConfig.NIGHT_SIGN_TEXTS.get();
                if (!texts.isEmpty()) {
                    String text = texts.get(random.nextInt(texts.size()));
                    SignText front = signBlockEntity.getFrontText();
                    signBlockEntity.setText(front.setMessage(0, Component.literal(text)), true);
                    signBlockEntity.setChanged();
                }
            }
            return "A night sign appeared at " + formatPos(signPos) + ".";
        }

        return null;
    }

    private static String placeRedTorch(ServerLevel level, ServerPlayer player, RandomSource random) {
        int radius = LivingWorldConfig.EVENT_RADIUS.get() + 2;

        for (int i = 0; i < 70; i++) {
            BlockPos pos = randomAround(player.blockPosition(), random, radius, 4);
            if (!level.isEmptyBlock(pos)) {
                continue;
            }

            if (level.getBlockState(pos.below()).isAir()) {
                continue;
            }

            if (WorldSightUtil.isBlockObserved(player, pos, 50.0D)) {
                continue;
            }

            if (!Blocks.REDSTONE_TORCH.defaultBlockState().canSurvive(level, pos)) {
                continue;
            }

            level.setBlock(pos, Blocks.REDSTONE_TORCH.defaultBlockState(), Block.UPDATE_ALL);
            return "A redstone torch appeared at " + formatPos(pos) + ".";
        }

        return null;
    }

    private static BlockPos randomAround(BlockPos center, RandomSource random, int horizontalRadius, int verticalRadius) {
        int x = center.getX() + random.nextInt(horizontalRadius * 2 + 1) - horizontalRadius;
        int y = center.getY() + random.nextInt(verticalRadius * 2 + 1) - verticalRadius;
        int z = center.getZ() + random.nextInt(horizontalRadius * 2 + 1) - horizontalRadius;
        return new BlockPos(x, y, z);
    }

    private static String formatPos(BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }
}
