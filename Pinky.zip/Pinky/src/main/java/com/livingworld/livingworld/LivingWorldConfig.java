package com.livingworld.livingworld;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

public final class LivingWorldConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.IntValue MIN_EVENT_INTERVAL_SECONDS;
    public static final ForgeConfigSpec.IntValue MAX_EVENT_INTERVAL_SECONDS;
    public static final ForgeConfigSpec.IntValue MIN_WATCHER_INTERVAL_SECONDS;
    public static final ForgeConfigSpec.IntValue MAX_WATCHER_INTERVAL_SECONDS;
    public static final ForgeConfigSpec.IntValue DRAGON_PRANK_INTERVAL_SECONDS;
    public static final ForgeConfigSpec.IntValue MOB_SWARM_INTERVAL_SECONDS;
    public static final ForgeConfigSpec.IntValue EVENT_RADIUS;
    public static final ForgeConfigSpec.IntValue HOME_STAY_SECONDS;

    public static final ForgeConfigSpec.IntValue SANITY_MAX;
    public static final ForgeConfigSpec.IntValue SANITY_GAIN_NIGHT;
    public static final ForgeConfigSpec.IntValue SANITY_GAIN_DARKNESS;
    public static final ForgeConfigSpec.IntValue SANITY_GAIN_ALONE;
    public static final ForgeConfigSpec.IntValue SANITY_GAIN_RECENT_EVENT;
    public static final ForgeConfigSpec.IntValue SANITY_DAY_DECAY;

    public static final ForgeConfigSpec.IntValue WATCHER_LIFETIME_SECONDS;
    public static final ForgeConfigSpec.IntValue MOB_SWARM_MIN_COUNT;
    public static final ForgeConfigSpec.IntValue MOB_SWARM_MAX_COUNT;
    public static final ForgeConfigSpec.IntValue WARDEN_CHANCE_PERCENT;
    public static final ForgeConfigSpec.BooleanValue DEBUG_CHAT_ACTIONS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> NIGHT_SIGN_TEXTS;

    public static final ForgeConfigSpec COMMON_SPEC;

    static {
        BUILDER.push("timing");
        MIN_EVENT_INTERVAL_SECONDS = BUILDER
                .comment("Minimum delay between world oddities around one player")
                .defineInRange("minEventIntervalSeconds", 10, 3, 600);
        MAX_EVENT_INTERVAL_SECONDS = BUILDER
                .comment("Maximum delay between world oddities around one player")
                .defineInRange("maxEventIntervalSeconds", 15, 3, 900);
        MIN_WATCHER_INTERVAL_SECONDS = BUILDER
                .comment("Minimum delay between fake watcher spawns")
                .defineInRange("minWatcherIntervalSeconds", 35, 8, 600);
        MAX_WATCHER_INTERVAL_SECONDS = BUILDER
                .comment("Maximum delay between fake watcher spawns")
                .defineInRange("maxWatcherIntervalSeconds", 90, 10, 900);
        DRAGON_PRANK_INTERVAL_SECONDS = BUILDER
                .comment("Delay between fake dragon pop-ins")
                .defineInRange("dragonPrankIntervalSeconds", 60, 10, 3600);
        MOB_SWARM_INTERVAL_SECONDS = BUILDER
                .comment("Delay between random peaceful mob swarms")
                .defineInRange("mobSwarmIntervalSeconds", 180, 20, 3600);
        EVENT_RADIUS = BUILDER
                .comment("How far from player the oddities can happen")
                .defineInRange("eventRadius", 14, 6, 48);
        HOME_STAY_SECONDS = BUILDER
                .comment("How long player needs to spend around one area before house events unlock")
                .defineInRange("homeStaySeconds", 240, 30, 7200);
        BUILDER.pop();

        BUILDER.push("sanity");
        SANITY_MAX = BUILDER
                .comment("Hard cap for hidden sanity value")
                .defineInRange("sanityMax", 100, 10, 10000);
        SANITY_GAIN_NIGHT = BUILDER
                .comment("Sanity gain per second at night")
                .defineInRange("sanityGainNight", 1, 0, 30);
        SANITY_GAIN_DARKNESS = BUILDER
                .comment("Sanity gain per second in darkness")
                .defineInRange("sanityGainDarkness", 1, 0, 30);
        SANITY_GAIN_ALONE = BUILDER
                .comment("Sanity gain per second when no players are nearby")
                .defineInRange("sanityGainAlone", 1, 0, 30);
        SANITY_GAIN_RECENT_EVENT = BUILDER
                .comment("Sanity gain per second after recent strange events")
                .defineInRange("sanityGainRecentEvent", 1, 0, 30);
        SANITY_DAY_DECAY = BUILDER
                .comment("Sanity decay per second in calm daylight")
                .defineInRange("sanityDayDecay", 2, 0, 30);
        BUILDER.pop();

        BUILDER.push("nightEvents");
        WATCHER_LIFETIME_SECONDS = BUILDER
                .comment("How long fake entities stay alive before auto despawn")
                .defineInRange("watcherLifetimeSeconds", 7, 2, 40);
        MOB_SWARM_MIN_COUNT = BUILDER
                .comment("Minimum number of peaceful mobs in prank swarm")
                .defineInRange("mobSwarmMinCount", 50, 1, 500);
        MOB_SWARM_MAX_COUNT = BUILDER
                .comment("Maximum number of peaceful mobs in prank swarm")
                .defineInRange("mobSwarmMaxCount", 200, 1, 500);
        WARDEN_CHANCE_PERCENT = BUILDER
                .comment("Chance in percent to spawn wardens instead of peaceful mobs")
                .defineInRange("wardenChancePercent", 2, 0, 100);
        DEBUG_CHAT_ACTIONS = BUILDER
                .comment("When true, all prank actions are printed to player chat")
                .define("debugChatActions", false);
        NIGHT_SIGN_TEXTS = BUILDER
                .comment("Texts used by occasional night signs")
                .defineListAllowEmpty(
                        "nightSignTexts",
                        List.of(
                                "I can hear your steps.",
                                "The house moved again.",
                                "Do not blink.",
                                "Turn around.",
                                "I watch in silence.",
                                "You are not alone."
                        ),
                        value -> value instanceof String s && !s.trim().isEmpty()
                );
        BUILDER.pop();

        COMMON_SPEC = BUILDER.build();
    }

    private LivingWorldConfig() {
    }

    public static int getMinEventIntervalTicks() {
        return Math.max(20, MIN_EVENT_INTERVAL_SECONDS.get() * 20);
    }

    public static int getMaxEventIntervalTicks() {
        return Math.max(getMinEventIntervalTicks(), MAX_EVENT_INTERVAL_SECONDS.get() * 20);
    }

    public static int getMinWatcherIntervalTicks() {
        return Math.max(20, MIN_WATCHER_INTERVAL_SECONDS.get() * 20);
    }

    public static int getMaxWatcherIntervalTicks() {
        return Math.max(getMinWatcherIntervalTicks(), MAX_WATCHER_INTERVAL_SECONDS.get() * 20);
    }

    public static int getDragonPrankIntervalTicks() {
        return Math.max(20, DRAGON_PRANK_INTERVAL_SECONDS.get() * 20);
    }

    public static int getMobSwarmIntervalTicks() {
        return Math.max(20, MOB_SWARM_INTERVAL_SECONDS.get() * 20);
    }

    public static int getMobSwarmMaxCount() {
        return Math.max(MOB_SWARM_MIN_COUNT.get(), MOB_SWARM_MAX_COUNT.get());
    }
}
