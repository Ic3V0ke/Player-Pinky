package com.livingworld.livingworld.prank;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class DragonPrankSystem {
    private static final Map<UUID, ActiveDragon> ACTIVE = new HashMap<>();

    private DragonPrankSystem() {
    }

    public static String trySpawn(ServerPlayer player) {
        if (ACTIVE.containsKey(player.getUUID())) {
            return null;
        }

        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle().normalize();
        Vec3 target = eye.add(look.scale(22.0D));

        BlockPos spawnPos = findAirColumn(level, BlockPos.containing(target));
        if (spawnPos == null) {
            return null;
        }

        EnderDragon dragon = EntityType.ENDER_DRAGON.create(level);
        if (dragon == null) {
            return null;
        }

        dragon.moveTo(spawnPos.getX() + 0.5D, spawnPos.getY(), spawnPos.getZ() + 0.5D, player.getYRot() + 180.0F, 0.0F);
        dragon.setNoAi(true);
        dragon.setInvulnerable(true);
        dragon.setSilent(true);

        if (!level.addFreshEntity(dragon)) {
            return null;
        }

        ACTIVE.put(player.getUUID(), new ActiveDragon(dragon.getUUID(), level.dimension(), level.getGameTime() + 20L));
        return "Global prank: Ender Dragon spawned for 1 second (visible to all).";
    }

    public static void tick(MinecraftServer server) {
        if (ACTIVE.isEmpty()) {
            return;
        }

        ACTIVE.entrySet().removeIf(entry -> {
            ActiveDragon dragon = entry.getValue();
            ServerLevel level = server.getLevel(dragon.dimension());
            if (level == null) {
                return true;
            }

            Entity entity = level.getEntity(dragon.entityId());
            if (entity == null) {
                return true;
            }

            if (!entity.isAlive() || level.getGameTime() >= dragon.expireTick()) {
                entity.discard();
                return true;
            }

            return false;
        });
    }

    public static void forget(UUID playerId, MinecraftServer server) {
        ActiveDragon dragon = ACTIVE.remove(playerId);
        if (dragon == null) {
            return;
        }

        ServerLevel level = server.getLevel(dragon.dimension());
        if (level == null) {
            return;
        }

        Entity entity = level.getEntity(dragon.entityId());
        if (entity != null) {
            entity.discard();
        }
    }

    private static BlockPos findAirColumn(ServerLevel level, BlockPos origin) {
        for (int dy = 6; dy >= -6; dy--) {
            BlockPos pos = origin.offset(0, dy, 0);
            if (!level.hasChunkAt(pos)) {
                continue;
            }

            if (level.isEmptyBlock(pos) && level.isEmptyBlock(pos.above())) {
                return pos;
            }
        }

        return null;
    }

    private record ActiveDragon(UUID entityId, ResourceKey<Level> dimension, long expireTick) {
    }
}
