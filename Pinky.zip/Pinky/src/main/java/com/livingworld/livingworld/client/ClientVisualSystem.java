package com.livingworld.livingworld.client;

import com.livingworld.livingworld.LivingWorldMod;
import com.livingworld.livingworld.client.music.MusicPlaybackEngine;
import com.livingworld.livingworld.client.music.PinkyKeyMappings;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientVisualSystem {
    private ClientVisualSystem() {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        ClientPrankEntityManager.tick();
        ClientPrankBlockManager.tick();
        ClientActionManager.tick();
        MusicPlaybackEngine.tickClientVolume();
        PinkyKeyMappings.tick();
    }
}
