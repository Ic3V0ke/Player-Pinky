package com.livingworld.livingworld.network;

import com.livingworld.livingworld.client.ClientActionManager;
import com.livingworld.livingworld.prank.ClientActionType;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record ClientActionPacket(ClientActionType type, int durationTicks, int value) {
    public static void encode(ClientActionPacket message, FriendlyByteBuf buffer) {
        buffer.writeEnum(message.type);
        buffer.writeVarInt(message.durationTicks);
        buffer.writeVarInt(message.value);
    }

    public static ClientActionPacket decode(FriendlyByteBuf buffer) {
        ClientActionType type = buffer.readEnum(ClientActionType.class);
        int durationTicks = buffer.readVarInt();
        int value = buffer.readVarInt();
        return new ClientActionPacket(type, durationTicks, value);
    }

    public static void handle(ClientActionPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                ClientActionManager.handle(message.type, message.durationTicks, message.value)
        ));
        context.setPacketHandled(true);
    }
}
