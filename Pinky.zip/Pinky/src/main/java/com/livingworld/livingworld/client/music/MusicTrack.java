package com.livingworld.livingworld.client.music;

import java.nio.file.Path;

public record MusicTrack(Path audioPath, Path coverPath, String artist, String title, String extension) {
    public String displayName() {
        if (artist == null || artist.isBlank() || "Unknown Artist".equals(artist)) {
            return title;
        }
        return artist + " - " + title;
    }

    public boolean hasCover() {
        return coverPath != null;
    }
}
