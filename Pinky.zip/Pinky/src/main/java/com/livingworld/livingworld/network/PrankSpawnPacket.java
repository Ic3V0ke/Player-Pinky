package com.livingworld.livingworld.network;

import com.livingworld.livingworld.client.ClientPrankEntityManager;
import com.livingworld.livingworld.prank.PrankSpawnPlan;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public record PrankSpawnPacket(int lifetimeTicks, List<PrankSpawnPlan.SpawnEntry> entries) {
    public static void encode(PrankSpawnPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.lifetimeTicks);
        buffer.writeVarInt(message.entries.size());
        for (PrankSpawnPlan.SpawnEntry entry : message.entries) {
            buffer.writeResourceLocation(entry.entityTypeId());
            buffer.writeDouble(entry.x());
            buffer.writeDouble(entry.y());
            buffer.writeDouble(entry.z());
            buffer.writeFloat(entry.yRot());
        }
    }

    public static PrankSpawnPacket decode(FriendlyByteBuf buffer) {
        int lifetimeTicks = buffer.readVarInt();
        int size = buffer.readVarInt();
        List<PrankSpawnPlan.SpawnEntry> entries = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            ResourceLocation entityTypeId = buffer.readResourceLocation();
            double x = buffer.readDouble();
            double y = buffer.readDouble();
            double z = buffer.readDouble();
            float yRot = buffer.readFloat();
            entries.add(new PrankSpawnPlan.SpawnEntry(entityTypeId, x, y, z, yRot));
        }
        return new PrankSpawnPacket(lifetimeTicks, entries);
    }

    public static void handle(PrankSpawnPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                ClientPrankEntityManager.spawn(message.lifetimeTicks, message.entries)
        ));
        context.setPacketHandled(true);
    }
}
