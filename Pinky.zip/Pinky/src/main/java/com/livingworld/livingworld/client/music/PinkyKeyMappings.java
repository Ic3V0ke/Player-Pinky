package com.livingworld.livingworld.client.music;

import com.livingworld.livingworld.LivingWorldMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class PinkyKeyMappings {
    public static final KeyMapping OPEN_PLAYER = new KeyMapping(
            "key.livingworld.open_pinky_player",
            KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_N,
            "key.categories.livingworld"
    );

    private PinkyKeyMappings() {
    }

    @SubscribeEvent
    public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(OPEN_PLAYER);
    }

    public static void tick() {
        Minecraft minecraft = Minecraft.getInstance();
        while (OPEN_PLAYER.consumeClick()) {
            if (minecraft.screen == null) {
                minecraft.setScreen(new PinkyMusicScreen());
            }
        }
    }
}
