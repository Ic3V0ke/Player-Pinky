package com.livingworld.livingworld.world;

import com.livingworld.livingworld.LivingWorldConfig;
import com.livingworld.livingworld.prank.PrankBlockPlan;
import com.livingworld.livingworld.util.WorldSightUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class BlockOdditySystem {
    private static final Set<Block> PRIORITY_BLOCKS = Set.of(
            Blocks.CRAFTING_TABLE,
            Blocks.FURNACE,
            Blocks.BLAST_FURNACE,
            Blocks.SMOKER,
            Blocks.CARTOGRAPHY_TABLE,
            Blocks.SMITHING_TABLE,
            Blocks.STONECUTTER,
            Blocks.ANVIL,
            Blocks.CHIPPED_ANVIL,
            Blocks.DAMAGED_ANVIL,
            Blocks.CHEST,
            Blocks.TRAPPED_CHEST,
            Blocks.BARREL
    );

    private BlockOdditySystem() {
    }

    public static PrankBlockPlan trigger(ServerPlayer player, double sanityFactor) {
        ServerLevel level = player.serverLevel();
        RandomSource random = level.random;

        BlockPos source = findPrioritySource(level, player, random);
        if (source == null) {
            source = findGeneralSource(level, player, random);
        }

        if (source == null) {
            return null;
        }

        BlockPos target = findMoveTarget(level, player, source, random);
        if (target == null) {
            return null;
        }

        BlockState sourceState = level.getBlockState(source);
        BlockState targetOriginal = level.getBlockState(target);
        if (sourceState.equals(targetOriginal)) {
            return null;
        }

        List<PrankBlockPlan.BlockChange> changes = new ArrayList<>(2);
        changes.add(new PrankBlockPlan.BlockChange(source, Block.getId(sourceState), Block.getId(targetOriginal)));
        changes.add(new PrankBlockPlan.BlockChange(target, Block.getId(targetOriginal), Block.getId(sourceState)));

        int lifetimeTicks = 20 * 20;

        return new PrankBlockPlan(
                lifetimeTicks,
                "Local block crawl: " + formatPos(source) + " -> " + formatPos(target) + " (auto revert).",
                changes
        );
    }

    private static BlockPos findPrioritySource(ServerLevel level, ServerPlayer player, RandomSource random) {
        int radius = Math.max(6, LivingWorldConfig.EVENT_RADIUS.get());

        for (int i = 0; i < 120; i++) {
            BlockPos pos = randomAround(player.blockPosition(), radius, 5, random);
            if (!level.hasChunkAt(pos)) {
                continue;
            }

            BlockState state = level.getBlockState(pos);
            if (!PRIORITY_BLOCKS.contains(state.getBlock())) {
                continue;
            }

            if (WorldSightUtil.isBlockObserved(player, pos, 55.0D)) {
                continue;
            }

            return pos;
        }

        return null;
    }

    private static BlockPos findGeneralSource(ServerLevel level, ServerPlayer player, RandomSource random) {
        int radius = LivingWorldConfig.EVENT_RADIUS.get();

        for (int i = 0; i < 220; i++) {
            BlockPos pos = randomAround(player.blockPosition(), radius, 5, random);
            if (!level.hasChunkAt(pos)) {
                continue;
            }

            BlockState state = level.getBlockState(pos);
            if (state.isAir() || state.is(Blocks.BEDROCK) || state.getDestroySpeed(level, pos) < 0.0F) {
                continue;
            }

            if (WorldSightUtil.isBlockObserved(player, pos, 55.0D)) {
                continue;
            }

            return pos;
        }

        return null;
    }

    private static BlockPos findMoveTarget(ServerLevel level, ServerPlayer player, BlockPos source, RandomSource random) {
        List<Direction> directions = new ArrayList<>(List.of(
                Direction.NORTH,
                Direction.SOUTH,
                Direction.WEST,
                Direction.EAST,
                Direction.UP,
                Direction.DOWN
        ));

        // Shuffle directions so movement feels random and includes vertical shifts.
        for (int i = directions.size() - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            Direction tmp = directions.get(i);
            directions.set(i, directions.get(j));
            directions.set(j, tmp);
        }

        for (Direction direction : directions) {
            BlockPos target = source.relative(direction);
            if (!level.hasChunkAt(target)) {
                continue;
            }

            if (target.equals(source)) {
                continue;
            }

            if (WorldSightUtil.isBlockObserved(player, target, 55.0D)) {
                continue;
            }

            BlockState targetState = level.getBlockState(target);
            if (targetState.is(Blocks.BEDROCK) || targetState.getDestroySpeed(level, target) < 0.0F) {
                continue;
            }

            return target;
        }

        return null;
    }

    private static BlockPos randomAround(BlockPos center, int horizontalRadius, int verticalRadius, RandomSource random) {
        int x = center.getX() + random.nextInt(horizontalRadius * 2 + 1) - horizontalRadius;
        int y = center.getY() + random.nextInt(verticalRadius * 2 + 1) - verticalRadius;
        int z = center.getZ() + random.nextInt(horizontalRadius * 2 + 1) - horizontalRadius;
        return new BlockPos(x, y, z);
    }

    private static String formatPos(BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }
}
