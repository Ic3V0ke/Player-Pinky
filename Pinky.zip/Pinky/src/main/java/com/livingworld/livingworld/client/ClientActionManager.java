package com.livingworld.livingworld.client;

import com.livingworld.livingworld.prank.ClientActionType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ClientActionManager {
    private static final RandomSource RANDOM = RandomSource.create();

    private static int cursorHideTicks;
    private static boolean cursorHiddenNow;

    private static int stolenSlot = -1;
    private static int stolenTicks;
    private static ItemStack stolenSnapshot = ItemStack.EMPTY;

    private static int crouchTicks;
    private static boolean crouchForced;
    private static int jumpTicks;
    private static int jumpPulseCooldown;

    private static int slipperyTicks;
    private static int slipperyRefreshCooldown;
    private static int slipperyRadius;
    private static final Map<BlockPos, BlockState> SLIPPERY_ENTRIES = new HashMap<>();

    private ClientActionManager() {
    }

    public static void handle(ClientActionType type, int durationTicks, int value) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) {
            return;
        }

        switch (type) {
            case HIDE_CURSOR -> cursorHideTicks = Math.max(cursorHideTicks, durationTicks);
            case STEAL_ITEM -> startItemSteal(minecraft.player, value, durationTicks);
            case FORCE_CROUCH -> crouchTicks = Math.max(crouchTicks, durationTicks);
            case FORCE_JUMP -> jumpTicks = Math.max(jumpTicks, durationTicks);
            case SOUND_CREEPER -> playBehindPlayerSound(minecraft.player, SoundEvents.CREEPER_PRIMED, 0.85F, 0.95F);
            case SOUND_ANVIL -> playBehindPlayerSound(minecraft.player, SoundEvents.ANVIL_LAND, 0.8F, 0.95F);
            case SOUND_TNT -> playBehindPlayerSound(minecraft.player, SoundEvents.TNT_PRIMED, 0.9F, 1.0F);
            case SLIPPERY_FLOOR -> applySlipperyFloor(minecraft.player, durationTicks, value);
        }
    }

    public static void tick() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null) {
            restoreCursorIfNeeded(minecraft);
            return;
        }

        tickCursor(minecraft);
        tickStolenItem(minecraft.player);
        tickForcedCrouch(minecraft.player);
        tickForcedJump(minecraft.player);
        tickSlipperyFloor(minecraft);
    }

    private static void tickCursor(Minecraft minecraft) {
        if (cursorHideTicks > 0) {
            cursorHideTicks--;
            if (minecraft.screen instanceof AbstractContainerScreen<?>) {
                setCursorHidden(minecraft, true);
                return;
            }

            // If player closed inventory while prank is active, force game mouse grab back.
            if (minecraft.screen == null && !minecraft.mouseHandler.isMouseGrabbed()) {
                minecraft.mouseHandler.grabMouse();
            }

            // In non-container screens we should not keep hidden cursor mode.
            if (cursorHiddenNow) {
                setCursorHidden(minecraft, false);
            }
            return;
        }

        restoreCursorIfNeeded(minecraft);
    }

    private static void restoreCursorIfNeeded(Minecraft minecraft) {
        if (cursorHiddenNow) {
            setCursorHidden(minecraft, false);
        }
        if (minecraft.screen == null && !minecraft.mouseHandler.isMouseGrabbed()) {
            minecraft.mouseHandler.grabMouse();
        }
    }

    private static void setCursorHidden(Minecraft minecraft, boolean hidden) {
        if (cursorHiddenNow == hidden) {
            return;
        }

        long window = minecraft.getWindow().getWindow();
        GLFW.glfwSetInputMode(window, GLFW.GLFW_CURSOR, hidden ? GLFW.GLFW_CURSOR_HIDDEN : GLFW.GLFW_CURSOR_NORMAL);
        cursorHiddenNow = hidden;
    }

    private static void startItemSteal(Player player, int slot, int durationTicks) {
        if (slot < 0 || slot >= player.getInventory().items.size()) {
            return;
        }

        ItemStack stack = player.getInventory().items.get(slot);
        if (stack.isEmpty()) {
            return;
        }

        stolenSlot = slot;
        stolenTicks = Math.max(1, durationTicks);
        stolenSnapshot = stack.copy();
        player.getInventory().items.set(slot, ItemStack.EMPTY);
    }

    private static void tickStolenItem(Player player) {
        if (stolenTicks <= 0 || stolenSlot < 0) {
            return;
        }

        stolenTicks--;

        if (stolenSlot < player.getInventory().items.size()) {
            player.getInventory().items.set(stolenSlot, ItemStack.EMPTY);
        }

        if (stolenTicks <= 0) {
            restoreStolenItem(player);
        }
    }

    private static void restoreStolenItem(Player player) {
        if (stolenSlot < 0 || stolenSnapshot.isEmpty()) {
            stolenSlot = -1;
            stolenSnapshot = ItemStack.EMPTY;
            return;
        }

        if (stolenSlot < player.getInventory().items.size() && player.getInventory().items.get(stolenSlot).isEmpty()) {
            player.getInventory().items.set(stolenSlot, stolenSnapshot.copy());
        } else {
            int free = findFreeSlot(player);
            if (free >= 0) {
                player.getInventory().items.set(free, stolenSnapshot.copy());
            } else if (stolenSlot < player.getInventory().items.size()) {
                player.getInventory().items.set(stolenSlot, stolenSnapshot.copy());
            }
        }

        stolenSlot = -1;
        stolenSnapshot = ItemStack.EMPTY;
    }

    private static int findFreeSlot(Player player) {
        for (int i = 0; i < player.getInventory().items.size(); i++) {
            if (player.getInventory().items.get(i).isEmpty()) {
                return i;
            }
        }
        return -1;
    }

    private static void tickForcedCrouch(Player player) {
        Minecraft minecraft = Minecraft.getInstance();
        if (crouchTicks > 0) {
            crouchTicks--;
            minecraft.options.keyShift.setDown(true);
            player.setShiftKeyDown(true);
            crouchForced = true;
        } else {
            if (crouchForced) {
                minecraft.options.keyShift.setDown(false);
                player.setShiftKeyDown(false);
                crouchForced = false;
            }
        }
    }

    private static void tickForcedJump(Player player) {
        if (jumpTicks <= 0) {
            return;
        }

        jumpTicks--;
        jumpPulseCooldown--;
        if (jumpPulseCooldown <= 0 && player.onGround()) {
            player.jumpFromGround();
            jumpPulseCooldown = 6;
        }
    }

    private static void playBehindPlayerSound(Player player, net.minecraft.sounds.SoundEvent soundEvent, float volume, float pitchBase) {
        if (player.level() == null) {
            return;
        }

        double x = player.getX() - player.getLookAngle().x * 3.0D;
        double y = player.getY() + 0.2D;
        double z = player.getZ() - player.getLookAngle().z * 3.0D;

        float pitch = pitchBase + (RANDOM.nextFloat() - 0.5F) * 0.15F;
        player.level().playLocalSound(x, y, z, soundEvent, SoundSource.HOSTILE, volume, pitch, false);
    }

    private static void applySlipperyFloor(Player player, int durationTicks, int radiusValue) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return;
        }

        restoreSlipperyFloor(minecraft);

        slipperyRadius = Mth.clamp(radiusValue, 10, 15);
        slipperyTicks = Math.max(1, durationTicks);
        slipperyRefreshCooldown = 0;
        extendSlipperyArea(minecraft, player);
        reapplySlipperyFloor(minecraft, player);
    }

    private static void tickSlipperyFloor(Minecraft minecraft) {
        if (slipperyTicks <= 0) {
            return;
        }

        Player player = minecraft.player;
        if (player == null) {
            return;
        }

        slipperyTicks--;
        slipperyRefreshCooldown--;

        if (slipperyRefreshCooldown <= 0) {
            extendSlipperyArea(minecraft, player);
            reapplySlipperyFloor(minecraft, player);
            slipperyRefreshCooldown = 1; // Reapply every tick for stable local override.
        }

        if (slipperyTicks <= 0) {
            restoreSlipperyFloor(minecraft);
        }
    }

    private static void extendSlipperyArea(Minecraft minecraft, Player player) {
        if (minecraft.level == null) {
            return;
        }

        BlockPos center = player.blockPosition();
        for (int x = -slipperyRadius; x <= slipperyRadius; x++) {
            for (int z = -slipperyRadius; z <= slipperyRadius; z++) {
                if (x * x + z * z > slipperyRadius * slipperyRadius) {
                    continue;
                }

                int worldX = center.getX() + x;
                int worldZ = center.getZ() + z;
                int y = minecraft.level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, worldX, worldZ) - 1;
                BlockPos pos = new BlockPos(worldX, y, worldZ);
                if (!minecraft.level.hasChunkAt(pos)) {
                    continue;
                }

                if (SLIPPERY_ENTRIES.containsKey(pos)) {
                    continue;
                }

                BlockState current = minecraft.level.getBlockState(pos);
                if (current.isAir()) {
                    continue;
                }

                if (current.is(Blocks.ICE) || current.is(Blocks.PACKED_ICE) || current.is(Blocks.BLUE_ICE)) {
                    continue;
                }

                SLIPPERY_ENTRIES.put(pos.immutable(), current);
            }
        }
    }

    private static void reapplySlipperyFloor(Minecraft minecraft, Player player) {
        if (minecraft.level == null) {
            return;
        }

        BlockPos center = player.blockPosition();
        int maxDistanceSq = (slipperyRadius + 3) * (slipperyRadius + 3);

        for (Map.Entry<BlockPos, BlockState> entry : SLIPPERY_ENTRIES.entrySet()) {
            BlockPos pos = entry.getKey();
            if (!minecraft.level.hasChunkAt(pos)) {
                continue;
            }

            // Keep applying near player so movement does not break the slippery effect.
            int dx = pos.getX() - center.getX();
            int dz = pos.getZ() - center.getZ();
            if (dx * dx + dz * dz <= maxDistanceSq) {
                minecraft.level.setBlock(pos, Blocks.PACKED_ICE.defaultBlockState(), 3);
            }
        }
    }

    private static void restoreSlipperyFloor(Minecraft minecraft) {
        if (minecraft.level != null) {
            for (Map.Entry<BlockPos, BlockState> entry : SLIPPERY_ENTRIES.entrySet()) {
                if (minecraft.level.hasChunkAt(entry.getKey())) {
                    minecraft.level.setBlock(entry.getKey(), entry.getValue(), 3);
                }
            }
        }
        SLIPPERY_ENTRIES.clear();
        slipperyTicks = 0;
        slipperyRefreshCooldown = 0;
        slipperyRadius = 0;
    }
}
