package com.livingworld.livingworld.client.music;

import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.decoder.SampleBuffer;
import org.jflac.sound.spi.FlacAudioFileReader;
import org.jflac.sound.spi.FlacFormatConversionProvider;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.Locale;

public final class MusicPlaybackEngine {
    private static final Object LOCK = new Object();
    private static final int BUFFER_SIZE = 8192;

    private static volatile PlaybackJob activeJob;
    private static volatile MusicTrack currentTrack;
    private static volatile PlaybackState state = PlaybackState.STOPPED;
    private static volatile String status = "Ready";
    private static volatile double progressSeconds;
    private static volatile double durationSeconds;
    private static volatile float categoryVolume = 1.0F;
    private static volatile float playerVolume = 0.88F;

    private MusicPlaybackEngine() {
    }

    public static void play(MusicTrack track) {
        if (track == null) {
            return;
        }

        stop();
        PlaybackJob job = new PlaybackJob(track);
        synchronized (LOCK) {
            currentTrack = track;
            state = PlaybackState.PLAYING;
            status = "Playing";
            progressSeconds = 0.0D;
            durationSeconds = probeDurationSeconds(track);
            activeJob = job;
        }

        Thread thread = new Thread(job, "Pinky Music Player");
        thread.setDaemon(true);
        thread.start();
    }

    public static void stop() {
        PlaybackJob job;
        synchronized (LOCK) {
            job = activeJob;
            activeJob = null;
            currentTrack = null;
            state = PlaybackState.STOPPED;
            status = "Stopped";
            progressSeconds = 0.0D;
            durationSeconds = 0.0D;
        }
        if (job != null) {
            job.requestStop();
        }
    }

    public static void togglePause() {
        synchronized (LOCK) {
            if (state == PlaybackState.PLAYING) {
                state = PlaybackState.PAUSED;
                status = "Paused";
            } else if (state == PlaybackState.PAUSED) {
                state = PlaybackState.PLAYING;
                status = "Playing";
            }
        }
    }

    public static void setPlayerVolume(float volume) {
        playerVolume = clamp(volume, 0.0F, 1.0F);
    }

    public static float getPlayerVolume() {
        return playerVolume;
    }

    public static void tickClientVolume() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft == null || minecraft.options == null) {
            return;
        }
        categoryVolume = clamp(
                minecraft.options.getSoundSourceVolume(SoundSource.MASTER)
                        * minecraft.options.getSoundSourceVolume(SoundSource.WEATHER),
                0.0F,
                1.0F
        );
    }

    public static MusicTrack getCurrentTrack() {
        return currentTrack;
    }

    public static PlaybackState getState() {
        return state;
    }

    public static String getStatus() {
        return status;
    }

    public static double getProgressSeconds() {
        return progressSeconds;
    }

    public static double getDurationSeconds() {
        return durationSeconds;
    }

    public static boolean isPlaying(MusicTrack track) {
        return track != null && currentTrack != null && currentTrack.audioPath().equals(track.audioPath()) && state == PlaybackState.PLAYING;
    }

    public static boolean isPaused(MusicTrack track) {
        return track != null && currentTrack != null && currentTrack.audioPath().equals(track.audioPath()) && state == PlaybackState.PAUSED;
    }

    public static boolean isActive(MusicTrack track) {
        return track != null && currentTrack != null && currentTrack.audioPath().equals(track.audioPath())
                && (state == PlaybackState.PLAYING || state == PlaybackState.PAUSED);
    }

    public static String formatTime(double seconds) {
        if (!Double.isFinite(seconds) || seconds < 0.0D) {
            seconds = 0.0D;
        }
        int rounded = (int) Math.floor(seconds);
        int minutes = rounded / 60;
        int remainingSeconds = rounded % 60;
        return String.format("%d:%02d", minutes, remainingSeconds);
    }

    private static double probeDurationSeconds(MusicTrack track) {
        if ("mp3".equals(track.extension().toLowerCase(Locale.ROOT))) {
            double mp3Duration = probeMp3DurationSeconds(track);
            if (mp3Duration > 0.0D) {
                return mp3Duration;
            }
        }
        if ("flac".equals(track.extension().toLowerCase(Locale.ROOT))) {
            double flacDuration = probeFlacDurationSeconds(track);
            if (flacDuration > 0.0D) {
                return flacDuration;
            }
        }

        try {
            AudioFileFormat fileFormat = AudioSystem.getAudioFileFormat(track.audioPath().toFile());
            Object duration = fileFormat.properties().get("duration");
            if (duration instanceof Number number && number.longValue() > 0L) {
                return number.longValue() / 1_000_000.0D;
            }

            AudioFormat format = fileFormat.getFormat();
            if (fileFormat.getFrameLength() > 0 && format.getFrameRate() > 0.0F) {
                return fileFormat.getFrameLength() / format.getFrameRate();
            }
        } catch (IOException | UnsupportedAudioFileException ignored) {
            return 0.0D;
        }
        return 0.0D;
    }

    private static double probeFlacDurationSeconds(MusicTrack track) {
        try {
            AudioFileFormat fileFormat = new FlacAudioFileReader().getAudioFileFormat(track.audioPath().toFile());
            Object duration = fileFormat.properties().get("duration");
            if (duration instanceof Number number && number.longValue() > 0L) {
                return number.longValue() / 1_000_000.0D;
            }
            AudioFormat format = fileFormat.getFormat();
            if (fileFormat.getFrameLength() > 0 && format.getFrameRate() > 0.0F) {
                return fileFormat.getFrameLength() / format.getFrameRate();
            }
        } catch (IOException | UnsupportedAudioFileException ignored) {
            return 0.0D;
        }
        return 0.0D;
    }

    private static double probeMp3DurationSeconds(MusicTrack track) {
        try (InputStream input = new BufferedInputStream(Files.newInputStream(track.audioPath()))) {
            Bitstream bitstream = new Bitstream(input);
            try {
                Header header = bitstream.readFrame();
                if (header == null) {
                    return 0.0D;
                }
                long size = Files.size(track.audioPath());
                float totalMs = header.total_ms((int) Math.min(Integer.MAX_VALUE, size));
                return totalMs > 0.0F ? totalMs / 1000.0D : 0.0D;
            } finally {
                bitstream.close();
            }
        } catch (IOException | JavaLayerException ignored) {
            return 0.0D;
        }
    }

    private static AudioFormat decodedFormat(AudioFormat sourceFormat) {
        int channels = sourceFormat.getChannels() > 0 ? sourceFormat.getChannels() : 2;
        float sampleRate = sourceFormat.getSampleRate() > 0.0F ? sourceFormat.getSampleRate() : 44100.0F;
        return new AudioFormat(
                AudioFormat.Encoding.PCM_SIGNED,
                sampleRate,
                16,
                channels,
                channels * 2,
                sampleRate,
                false
        );
    }

    private static void applyGain(SourceDataLine line) {
        if (!line.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            return;
        }

        FloatControl gain = (FloatControl) line.getControl(FloatControl.Type.MASTER_GAIN);
        float effective = clamp(categoryVolume * playerVolume, 0.0F, 1.0F);
        float decibels = effective <= 0.0001F ? gain.getMinimum() : (float) (20.0D * Math.log10(effective));
        gain.setValue(clamp(decibels, gain.getMinimum(), gain.getMaximum()));
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static void markFinished(PlaybackJob job) {
        synchronized (LOCK) {
            if (activeJob != job) {
                return;
            }
            activeJob = null;
            state = PlaybackState.STOPPED;
            status = "Finished";
            currentTrack = null;
            progressSeconds = 0.0D;
            durationSeconds = 0.0D;
        }
    }

    private static void markError(PlaybackJob job, String message) {
        synchronized (LOCK) {
            if (activeJob != job) {
                return;
            }
            activeJob = null;
            state = PlaybackState.ERROR;
            status = message;
        }
    }

    public enum PlaybackState {
        STOPPED,
        PLAYING,
        PAUSED,
        ERROR
    }

    private static final class PlaybackJob implements Runnable {
        private final MusicTrack track;
        private volatile boolean stopRequested;
        private volatile SourceDataLine line;

        private PlaybackJob(MusicTrack track) {
            this.track = track;
        }

        private void requestStop() {
            stopRequested = true;
            SourceDataLine currentLine = line;
            if (currentLine != null) {
                currentLine.flush();
                currentLine.stop();
            }
        }

        @Override
        public void run() {
            if ("mp3".equals(track.extension().toLowerCase(Locale.ROOT))) {
                playMp3WithJLayer();
                return;
            }

            playWithJavaSound();
        }

        private void playWithJavaSound() {
            try (InputStream input = new BufferedInputStream(Files.newInputStream(track.audioPath()));
                 AudioInputStream source = openAudioInputStream(input)) {
                AudioFormat decodedFormat = decodedFormat(source.getFormat());
                try (AudioInputStream decoded = openDecodedStream(decodedFormat, source);
                     SourceDataLine outputLine = AudioSystem.getSourceDataLine(decodedFormat)) {
                    line = outputLine;
                    outputLine.open(decodedFormat);
                    outputLine.start();
                    playDecodedStream(decoded, decodedFormat, outputLine);
                    if (stopRequested) {
                        outputLine.flush();
                    } else {
                        outputLine.drain();
                    }
                }
                line = null;

                if (!stopRequested) {
                    markFinished(this);
                }
            } catch (UnsupportedAudioFileException exception) {
                markError(this, "Unsupported " + track.extension().toUpperCase() + " file");
            } catch (LineUnavailableException exception) {
                markError(this, "Audio device is busy");
            } catch (IOException | IllegalArgumentException exception) {
                String message = exception.getMessage();
                markError(this, message == null || message.isBlank() ? "Playback error" : message);
            } finally {
                line = null;
            }
        }

        private AudioInputStream openAudioInputStream(InputStream input) throws UnsupportedAudioFileException, IOException {
            if ("flac".equals(track.extension().toLowerCase(Locale.ROOT))) {
                return new FlacAudioFileReader().getAudioInputStream(input);
            }
            return AudioSystem.getAudioInputStream(input);
        }

        private AudioInputStream openDecodedStream(AudioFormat decodedFormat, AudioInputStream source) {
            if ("flac".equals(track.extension().toLowerCase(Locale.ROOT))) {
                return new FlacFormatConversionProvider().getAudioInputStream(decodedFormat, source);
            }
            return AudioSystem.getAudioInputStream(decodedFormat, source);
        }

        private void playMp3WithJLayer() {
            try (InputStream input = new BufferedInputStream(Files.newInputStream(track.audioPath()))) {
                Bitstream bitstream = new Bitstream(input);
                Decoder decoder = new Decoder();
                SourceDataLine outputLine = null;
                AudioFormat format = null;
                long bytesPlayed = 0L;

                try {
                    while (!stopRequested) {
                        Header header = bitstream.readFrame();
                        if (header == null) {
                            break;
                        }

                        SampleBuffer samples = (SampleBuffer) decoder.decodeFrame(header, bitstream);
                        if (outputLine == null) {
                            format = new AudioFormat(
                                    samples.getSampleFrequency(),
                                    16,
                                    samples.getChannelCount(),
                                    true,
                                    false
                            );
                            outputLine = AudioSystem.getSourceDataLine(format);
                            line = outputLine;
                            outputLine.open(format);
                            outputLine.start();
                        }

                        byte[] pcm = samplesToBytes(samples);
                        bytesPlayed += writeOutputBytes(outputLine, pcm, pcm.length);
                        if (format != null) {
                            updateProgress(format, bytesPlayed);
                        }
                        bitstream.closeFrame();
                    }

                    if (outputLine != null) {
                        if (stopRequested) {
                            outputLine.flush();
                        } else {
                            outputLine.drain();
                        }
                    }
                    if (!stopRequested) {
                        markFinished(this);
                    }
                } finally {
                    if (outputLine != null) {
                        outputLine.stop();
                        outputLine.close();
                    }
                    bitstream.close();
                    line = null;
                }
            } catch (JavaLayerException exception) {
                markError(this, "MP3 decoder error");
            } catch (LineUnavailableException exception) {
                markError(this, "Audio device is busy");
            } catch (IOException | IllegalArgumentException exception) {
                String message = exception.getMessage();
                markError(this, message == null || message.isBlank() ? "Playback error" : message);
            }
        }

        private void playDecodedStream(AudioInputStream decoded, AudioFormat format, SourceDataLine outputLine) throws IOException {
            byte[] buffer = new byte[BUFFER_SIZE];
            long bytesPlayed = 0L;
            boolean linePaused = false;

            while (!stopRequested) {
                if (state == PlaybackState.PAUSED) {
                    if (!linePaused) {
                        outputLine.stop();
                        linePaused = true;
                    }
                    sleepQuietly(25L);
                    continue;
                }

                if (linePaused) {
                    outputLine.start();
                    linePaused = false;
                }

                int read = decoded.read(buffer, 0, buffer.length);
                if (read < 0) {
                    break;
                }

                int offset = writeOutputBytes(outputLine, buffer, read);
                bytesPlayed += Math.max(0, offset);
                updateProgress(format, bytesPlayed);
            }
        }

        private int writeOutputBytes(SourceDataLine outputLine, byte[] buffer, int length) {
            int offset = 0;
            boolean linePaused = false;
            while (offset < length && !stopRequested) {
                if (state == PlaybackState.PAUSED) {
                    if (!linePaused) {
                        outputLine.stop();
                        linePaused = true;
                    }
                    sleepQuietly(25L);
                    continue;
                }

                if (linePaused) {
                    outputLine.start();
                    linePaused = false;
                }

                applyGain(outputLine);
                offset += outputLine.write(buffer, offset, length - offset);
            }
            return offset;
        }

        private static byte[] samplesToBytes(SampleBuffer samples) {
            short[] source = samples.getBuffer();
            int length = samples.getBufferLength();
            byte[] bytes = new byte[length * 2];
            for (int i = 0; i < length; i++) {
                short sample = source[i];
                bytes[i * 2] = (byte) (sample & 255);
                bytes[i * 2 + 1] = (byte) ((sample >>> 8) & 255);
            }
            return bytes;
        }

        private static void updateProgress(AudioFormat format, long bytesPlayed) {
            int frameSize = format.getFrameSize();
            float frameRate = format.getFrameRate();
            if (frameSize > 0 && frameRate > 0.0F) {
                progressSeconds = bytesPlayed / (frameSize * (double) frameRate);
            }
        }

        private static void sleepQuietly(long millis) {
            try {
                Thread.sleep(millis);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
