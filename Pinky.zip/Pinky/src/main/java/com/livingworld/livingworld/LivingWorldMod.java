package com.livingworld.livingworld;

import com.livingworld.livingworld.network.LivingWorldNetwork;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(LivingWorldMod.MOD_ID)
public class LivingWorldMod {
    public static final String MOD_ID = "livingworld";
    public static final Logger LOGGER = LogUtils.getLogger();

    public LivingWorldMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        modEventBus.addListener(this::onCommonSetup);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, LivingWorldConfig.COMMON_SPEC);
    }

    private void onCommonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(LivingWorldNetwork::register);
    }
}
