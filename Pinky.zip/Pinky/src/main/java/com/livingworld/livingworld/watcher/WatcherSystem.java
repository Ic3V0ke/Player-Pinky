package com.livingworld.livingworld.watcher;

import com.livingworld.livingworld.LivingWorldConfig;
import com.livingworld.livingworld.prank.PrankSpawnPlan;
import com.livingworld.livingworld.util.WorldSightUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;

import java.util.List;
import java.util.Optional;

public final class WatcherSystem {
    private static final EntityType<?>[] WATCHER_POOL = new EntityType<?>[]{
            EntityType.ENDERMAN,
            EntityType.SKELETON,
            EntityType.ZOMBIE,
            EntityType.WITHER_SKELETON
    };

    private WatcherSystem() {
    }

    public static PrankSpawnPlan create(ServerPlayer player, double sanityFactor) {
        ServerLevel level = player.serverLevel();
        Optional<BlockPos> spawnPosOptional = WorldSightUtil.findSpawnBehindPlayer(level, player, 9, 22, 18);
        if (spawnPosOptional.isEmpty()) {
            return null;
        }

        RandomSource random = level.random;
        EntityType<?> type = WATCHER_POOL[random.nextInt(WATCHER_POOL.length)];
        if (sanityFactor > 0.7D && random.nextFloat() < 0.35F) {
            type = EntityType.ENDERMAN;
        }

        ResourceLocation typeId = type == null ? null : EntityType.getKey(type);
        if (typeId == null) {
            return null;
        }

        BlockPos pos = spawnPosOptional.get();
        PrankSpawnPlan.SpawnEntry entry = new PrankSpawnPlan.SpawnEntry(
                typeId,
                pos.getX() + 0.5D,
                pos.getY(),
                pos.getZ() + 0.5D,
                player.getYRot() + 180.0F
        );

        return new PrankSpawnPlan(
                LivingWorldConfig.WATCHER_LIFETIME_SECONDS.get() * 20,
                "A local silhouette appeared behind you for a few seconds.",
                List.of(entry)
        );
    }
}
