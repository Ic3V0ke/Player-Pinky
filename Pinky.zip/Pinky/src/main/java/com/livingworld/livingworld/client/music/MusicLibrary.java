package com.livingworld.livingworld.client.music;

import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Stream;

public final class MusicLibrary {
    private static final Set<String> AUDIO_EXTENSIONS = Set.of("mp3", "flac", "wav", "aiff", "aif");
    private static final List<String> COVER_EXTENSIONS = List.of("jpg", "jpeg", "png");

    private MusicLibrary() {
    }

    public static List<MusicTrack> scanTracks() {
        List<MusicTrack> tracks = new ArrayList<>();
        Set<String> seenFiles = new HashSet<>();
        ensureDefaultMusicFolder();

        for (Path root : getCandidateRoots()) {
            if (!Files.isDirectory(root)) {
                continue;
            }

            try (Stream<Path> stream = Files.list(root)) {
                stream
                        .filter(Files::isRegularFile)
                        .filter(MusicLibrary::isAudioFile)
                        .sorted(Comparator.comparing(path -> path.getFileName().toString().toLowerCase(Locale.ROOT)))
                        .forEach(path -> addTrack(path, tracks, seenFiles));
            } catch (IOException ignored) {
                // Broken music folders should not stop the client from opening the menu.
            }
        }

        tracks.sort(Comparator
                .comparing((MusicTrack track) -> track.artist().toLowerCase(Locale.ROOT))
                .thenComparing(track -> track.title().toLowerCase(Locale.ROOT))
                .thenComparing(track -> track.audioPath().getFileName().toString().toLowerCase(Locale.ROOT)));
        return tracks;
    }

    public static List<Path> getCandidateRoots() {
        LinkedHashSet<Path> roots = new LinkedHashSet<>();
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft != null && minecraft.gameDirectory != null) {
            Path gameDirectory = minecraft.gameDirectory.toPath().toAbsolutePath().normalize();
            roots.add(gameDirectory.resolve("music"));
            Path parent = gameDirectory.getParent();
            if (parent != null) {
                roots.add(parent.resolve("music"));
            }
        }

        Path currentDirectory = Path.of("").toAbsolutePath().normalize();
        roots.add(currentDirectory.resolve("music"));
        Path currentParent = currentDirectory.getParent();
        if (currentParent != null) {
            roots.add(currentParent.resolve("music"));
        }
        return new ArrayList<>(roots);
    }

    public static Path getDefaultMusicFolder() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft != null && minecraft.gameDirectory != null) {
            return minecraft.gameDirectory.toPath().toAbsolutePath().normalize().resolve("music");
        }
        return Path.of("").toAbsolutePath().normalize().resolve("music");
    }

    private static void ensureDefaultMusicFolder() {
        try {
            Files.createDirectories(getDefaultMusicFolder());
        } catch (IOException ignored) {
            // The player still scans any existing fallback folders.
        }
    }

    private static void addTrack(Path path, List<MusicTrack> tracks, Set<String> seenFiles) {
        try {
            String realPath = path.toRealPath().toString().toLowerCase(Locale.ROOT);
            if (!seenFiles.add(realPath)) {
                return;
            }
        } catch (IOException ignored) {
            String normalized = path.toAbsolutePath().normalize().toString().toLowerCase(Locale.ROOT);
            if (!seenFiles.add(normalized)) {
                return;
            }
        }

        String fileName = path.getFileName().toString();
        String extension = extension(fileName);
        String baseName = stripExtension(fileName);
        ParsedName parsedName = parseName(baseName);
        tracks.add(new MusicTrack(path.toAbsolutePath().normalize(), findCover(path), parsedName.artist(), parsedName.title(), extension));
    }

    private static boolean isAudioFile(Path path) {
        return AUDIO_EXTENSIONS.contains(extension(path.getFileName().toString()));
    }

    private static Path findCover(Path audioPath) {
        Path directory = audioPath.getParent();
        if (directory == null) {
            return null;
        }

        String baseName = stripExtension(audioPath.getFileName().toString());
        for (String extension : COVER_EXTENSIONS) {
            Path candidate = directory.resolve(baseName + "." + extension);
            if (Files.isRegularFile(candidate)) {
                return candidate.toAbsolutePath().normalize();
            }
        }

        for (String extension : COVER_EXTENSIONS) {
            Path candidate = directory.resolve("bak." + extension);
            if (Files.isRegularFile(candidate)) {
                return candidate.toAbsolutePath().normalize();
            }
        }

        return null;
    }

    private static ParsedName parseName(String baseName) {
        String cleaned = baseName.replace('_', ' ').trim();
        int divider = cleaned.indexOf(" - ");
        if (divider > 0 && divider < cleaned.length() - 3) {
            String artist = cleaned.substring(0, divider).trim();
            String title = cleaned.substring(divider + 3).trim();
            return new ParsedName(emptyFallback(artist, "Unknown Artist"), emptyFallback(title, cleaned));
        }
        return new ParsedName("Unknown Artist", emptyFallback(cleaned, "Untitled Track"));
    }

    private static String extension(String fileName) {
        int dot = fileName.lastIndexOf('.');
        if (dot < 0 || dot == fileName.length() - 1) {
            return "";
        }
        return fileName.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    private static String stripExtension(String fileName) {
        int dot = fileName.lastIndexOf('.');
        if (dot < 0) {
            return fileName;
        }
        return fileName.substring(0, dot);
    }

    private static String emptyFallback(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private record ParsedName(String artist, String title) {
    }
}
