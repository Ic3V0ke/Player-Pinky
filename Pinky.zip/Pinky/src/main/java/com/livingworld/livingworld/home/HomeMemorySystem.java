package com.livingworld.livingworld.home;

import com.livingworld.livingworld.LivingWorldConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class HomeMemorySystem {
    private static final Map<UUID, HomeProfile> PROFILES = new HashMap<>();

    private HomeMemorySystem() {
    }

    public static void tick(ServerPlayer player) {
        HomeProfile profile = PROFILES.computeIfAbsent(player.getUUID(), key -> new HomeProfile());
        profile.observe(player);
    }

    public static void forget(UUID playerId) {
        PROFILES.remove(playerId);
    }

    public static boolean hasEstablishedHome(ServerPlayer player) {
        HomeProfile profile = PROFILES.get(player.getUUID());
        return profile != null && profile.isEstablished();
    }

    public static BlockPos getAnchor(ServerPlayer player) {
        HomeProfile profile = PROFILES.get(player.getUUID());
        if (profile == null) {
            return player.blockPosition();
        }

        if (profile.bedPos != null) {
            return profile.bedPos;
        }

        return profile.anchor;
    }

    public static Optional<BlockPos> findNearbyChest(ServerPlayer player, int radius) {
        BlockPos center = getAnchor(player);
        RandomSource random = player.getRandom();

        for (int i = 0; i < 90; i++) {
            int x = center.getX() + random.nextInt(radius * 2 + 1) - radius;
            int y = center.getY() + random.nextInt(7) - 3;
            int z = center.getZ() + random.nextInt(radius * 2 + 1) - radius;

            BlockPos pos = new BlockPos(x, y, z);
            BlockState state = player.level().getBlockState(pos);
            if (state.getBlock() instanceof ChestBlock) {
                return Optional.of(pos);
            }
        }

        return Optional.empty();
    }

    private static final class HomeProfile {
        private final Map<Long, Integer> chunkVisits = new HashMap<>();

        private BlockPos anchor = BlockPos.ZERO;
        private BlockPos bedPos;
        private long bestChunk = ChunkPos.asLong(0, 0);
        private int bestScore = 0;
        private int residenceSeconds = 0;

        void observe(ServerPlayer player) {
            long chunkKey = ChunkPos.asLong(player.chunkPosition().x, player.chunkPosition().z);
            int score = chunkVisits.merge(chunkKey, 1, Integer::sum);
            if (score > bestScore) {
                bestScore = score;
                bestChunk = chunkKey;
                int chunkX = ChunkPos.getX(bestChunk) * 16 + 8;
                int chunkZ = ChunkPos.getZ(bestChunk) * 16 + 8;
                anchor = new BlockPos(chunkX, player.getBlockY(), chunkZ);
            }

            if (player.getRespawnPosition() != null) {
                bedPos = player.getRespawnPosition();
            }

            BlockPos focus = bedPos != null ? bedPos : anchor;
            double distanceSq = player.distanceToSqr(focus.getX() + 0.5D, focus.getY() + 0.5D, focus.getZ() + 0.5D);
            if (distanceSq <= 20.0D * 20.0D) {
                residenceSeconds++;
            } else {
                residenceSeconds = Math.max(0, residenceSeconds - 1);
            }
        }

        boolean isEstablished() {
            return residenceSeconds >= LivingWorldConfig.HOME_STAY_SECONDS.get();
        }
    }
}
