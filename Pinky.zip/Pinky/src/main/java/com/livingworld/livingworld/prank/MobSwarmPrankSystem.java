package com.livingworld.livingworld.prank;

import com.livingworld.livingworld.LivingWorldConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class MobSwarmPrankSystem {
    private static final Map<UUID, ActiveSwarm> ACTIVE = new HashMap<>();

    private MobSwarmPrankSystem() {
    }

    public static String trySpawn(ServerPlayer player) {
        if (ACTIVE.containsKey(player.getUUID())) {
            return null;
        }

        ServerLevel level = player.serverLevel();
        RandomSource random = level.random;

        int wardenChance = LivingWorldConfig.WARDEN_CHANCE_PERCENT.get();
        if (random.nextInt(100) < wardenChance) {
            int wanted = 1 + random.nextInt(4);
            List<UUID> spawned = spawnWardens(level, player, wanted, random);
            if (!spawned.isEmpty()) {
                ACTIVE.put(player.getUUID(), new ActiveSwarm(level.dimension(), spawned, level.getGameTime() + 60L));
                return "Global prank: wardens spawned nearby for 3s: " + spawned.size() + ".";
            }
            return null;
        }

        List<EntityType<?>> pool = getAllEggMobs(level);
        if (pool.isEmpty()) {
            return null;
        }

        int min = LivingWorldConfig.MOB_SWARM_MIN_COUNT.get();
        int max = LivingWorldConfig.getMobSwarmMaxCount();
        int target = Mth.nextInt(random, min, max);

        SpawnSummary summary = spawnRandom(level, player, pool, target, random);
        if (summary.entityIds.isEmpty()) {
            return null;
        }

        ACTIVE.put(player.getUUID(), new ActiveSwarm(level.dimension(), summary.entityIds, level.getGameTime() + 60L));
        return "Global prank: mob swarm spawned for 3s: " + summary.entityIds.size() + " mobs. " + summary.describe();
    }

    public static void tick(MinecraftServer server) {
        if (ACTIVE.isEmpty()) {
            return;
        }

        ACTIVE.entrySet().removeIf(entry -> {
            ActiveSwarm swarm = entry.getValue();
            ServerLevel level = server.getLevel(swarm.dimension());
            if (level == null) {
                return true;
            }

            if (level.getGameTime() < swarm.expireTick()) {
                return false;
            }

            for (UUID entityId : swarm.entityIds()) {
                Entity entity = level.getEntity(entityId);
                if (entity != null) {
                    entity.discard();
                }
            }
            return true;
        });
    }

    public static void forget(UUID playerId, MinecraftServer server) {
        ActiveSwarm swarm = ACTIVE.remove(playerId);
        if (swarm == null) {
            return;
        }

        ServerLevel level = server.getLevel(swarm.dimension());
        if (level == null) {
            return;
        }

        for (UUID entityId : swarm.entityIds()) {
            Entity entity = level.getEntity(entityId);
            if (entity != null) {
                entity.discard();
            }
        }
    }

    private static SpawnSummary spawnRandom(ServerLevel level, ServerPlayer player, List<EntityType<?>> pool, int targetCount, RandomSource random) {
        SpawnSummary summary = new SpawnSummary();
        int attempts = targetCount * 10;

        for (int i = 0; i < attempts && summary.entityIds.size() < targetCount; i++) {
            EntityType<?> type = pool.get(random.nextInt(pool.size()));
            BlockPos pos = randomSpawnPos(level, player, random, 18, 5);
            if (pos == null) {
                continue;
            }

            Entity entity = type.create(level);
            if (!(entity instanceof Mob mob)) {
                continue;
            }

            mob.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, random.nextFloat() * 360.0F, 0.0F);
            if (!level.noCollision(mob) || !level.addFreshEntity(mob)) {
                continue;
            }

            summary.entityIds.add(mob.getUUID());
            summary.byType.merge(BuiltInRegistries.ENTITY_TYPE.getKey(type).getPath(), 1, Integer::sum);
        }

        return summary;
    }

    private static List<UUID> spawnWardens(ServerLevel level, ServerPlayer player, int amount, RandomSource random) {
        List<UUID> entityIds = new ArrayList<>();
        int attempts = amount * 10;

        for (int i = 0; i < attempts && entityIds.size() < amount; i++) {
            BlockPos pos = randomSpawnPos(level, player, random, 22, 8);
            if (pos == null) {
                continue;
            }

            Warden warden = EntityType.WARDEN.create(level);
            if (warden == null) {
                continue;
            }

            warden.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, random.nextFloat() * 360.0F, 0.0F);
            if (!level.noCollision(warden) || !level.addFreshEntity(warden)) {
                continue;
            }

            entityIds.add(warden.getUUID());
        }

        return entityIds;
    }

    private static List<EntityType<?>> getAllEggMobs(ServerLevel level) {
        List<EntityType<?>> pool = new ArrayList<>();

        for (EntityType<?> type : ForgeRegistries.ENTITY_TYPES.getValues()) {
            if (type == EntityType.PLAYER || type == EntityType.ARMOR_STAND || type == EntityType.ENDER_DRAGON || type == EntityType.WITHER) {
                continue;
            }

            if (ForgeSpawnEggItem.fromEntityType(type) == null) {
                continue;
            }

            Entity entity = type.create(level);
            if (!(entity instanceof Mob)) {
                continue;
            }

            pool.add(type);
        }

        return pool;
    }

    private static BlockPos randomSpawnPos(ServerLevel level, ServerPlayer player, RandomSource random, int radius, int verticalOffset) {
        for (int i = 0; i < 24; i++) {
            int x = player.getBlockX() + random.nextInt(radius * 2 + 1) - radius;
            int z = player.getBlockZ() + random.nextInt(radius * 2 + 1) - radius;
            int groundY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            int y = groundY + random.nextInt(verticalOffset + 1);

            BlockPos pos = new BlockPos(x, y, z);
            if (!level.hasChunkAt(pos)) {
                continue;
            }

            if (level.isEmptyBlock(pos) && level.isEmptyBlock(pos.above()) && !level.getBlockState(pos.below()).isAir()) {
                return pos;
            }
        }

        return null;
    }

    private record ActiveSwarm(ResourceKey<Level> dimension, List<UUID> entityIds, long expireTick) {
    }

    private static final class SpawnSummary {
        private final List<UUID> entityIds = new ArrayList<>();
        private final Map<String, Integer> byType = new HashMap<>();

        String describe() {
            StringBuilder builder = new StringBuilder();
            boolean first = true;
            for (Map.Entry<String, Integer> entry : byType.entrySet()) {
                if (!first) {
                    builder.append(", ");
                }
                first = false;
                builder.append(entry.getKey()).append("=").append(entry.getValue());
            }
            return builder.toString();
        }
    }
}
