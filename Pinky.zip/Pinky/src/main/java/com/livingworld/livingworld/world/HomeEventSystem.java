package com.livingworld.livingworld.world;

import com.livingworld.livingworld.home.HomeMemorySystem;
import com.livingworld.livingworld.util.WorldSightUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

public final class HomeEventSystem {
    private static final Block[] GLASS_VARIANTS = new Block[]{
            Blocks.LIGHT_GRAY_STAINED_GLASS,
            Blocks.GRAY_STAINED_GLASS,
            Blocks.BLUE_STAINED_GLASS,
            Blocks.CYAN_STAINED_GLASS,
            Blocks.GREEN_STAINED_GLASS,
            Blocks.RED_STAINED_GLASS,
            Blocks.PURPLE_STAINED_GLASS,
            Blocks.BROWN_STAINED_GLASS
    };

    private HomeEventSystem() {
    }

    public static String trigger(ServerPlayer player, double sanityFactor) {
        if (!HomeMemorySystem.hasEstablishedHome(player)) {
            return null;
        }

        ServerLevel level = player.serverLevel();
        RandomSource random = level.random;

        for (int i = 0; i < 5; i++) {
            int action = random.nextInt(4);
            String result;
            switch (action) {
                case 0 -> result = toggleDoor(level, player, random);
                case 1 -> result = recolorWindow(level, player, random);
                case 2 -> result = nudgeInteriorBlock(level, player, random);
                default -> result = null;
            }

            if (result != null) {
                return result;
            }
        }

        return null;
    }

    private static String toggleDoor(ServerLevel level, ServerPlayer player, RandomSource random) {
        BlockPos anchor = HomeMemorySystem.getAnchor(player);

        for (int i = 0; i < 80; i++) {
            BlockPos pos = randomAround(anchor, random, 10, 3);
            BlockState state = level.getBlockState(pos);

            if (!(state.getBlock() instanceof DoorBlock)) {
                continue;
            }

            if (state.hasProperty(DoorBlock.HALF) && state.getValue(DoorBlock.HALF) != DoubleBlockHalf.LOWER) {
                continue;
            }

            if (WorldSightUtil.isBlockObserved(player, pos, 45.0D)) {
                continue;
            }

            if (state.hasProperty(DoorBlock.OPEN)) {
                level.setBlock(pos, state.cycle(DoorBlock.OPEN), Block.UPDATE_ALL);
                return "A house door toggled itself at " + formatPos(pos) + ".";
            }
        }

        return null;
    }

    private static String recolorWindow(ServerLevel level, ServerPlayer player, RandomSource random) {
        BlockPos anchor = HomeMemorySystem.getAnchor(player);

        for (int i = 0; i < 90; i++) {
            BlockPos pos = randomAround(anchor, random, 12, 4);
            BlockState state = level.getBlockState(pos);

            if (!(state.is(Blocks.GLASS) || state.is(Blocks.GLASS_PANE) || state.getBlock().toString().contains("stained_glass"))) {
                continue;
            }

            if (WorldSightUtil.isBlockObserved(player, pos, 45.0D)) {
                continue;
            }

            Block replacement = GLASS_VARIANTS[random.nextInt(GLASS_VARIANTS.length)];
            level.setBlock(pos, replacement.defaultBlockState(), Block.UPDATE_ALL);
            return "A house window changed color at " + formatPos(pos) + ".";
        }

        return null;
    }

    private static String nudgeInteriorBlock(ServerLevel level, ServerPlayer player, RandomSource random) {
        BlockPos anchor = HomeMemorySystem.getAnchor(player);

        for (int i = 0; i < 120; i++) {
            BlockPos source = randomAround(anchor, random, 8, 4);
            BlockState state = level.getBlockState(source);

            if (state.isAir() || state.is(Blocks.BEDROCK) || state.getDestroySpeed(level, source) < 0.0F) {
                continue;
            }

            if (state.hasBlockEntity()) {
                continue;
            }

            if (WorldSightUtil.isBlockObserved(player, source, 45.0D)) {
                continue;
            }

            BlockPos target = source.relative(WorldSightUtil.randomHorizontalDirection(random));
            if (!level.isEmptyBlock(target)) {
                continue;
            }

            if (!level.getBlockState(target.below()).isAir() && !WorldSightUtil.isBlockObserved(player, target, 45.0D)) {
                level.setBlock(target, state, Block.UPDATE_ALL);
                level.setBlock(source, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
                return "An indoor block moved from " + formatPos(source) + " to " + formatPos(target) + ".";
            }
        }

        return null;
    }

    private static BlockPos randomAround(BlockPos center, RandomSource random, int horizontalRadius, int verticalRadius) {
        int x = center.getX() + random.nextInt(horizontalRadius * 2 + 1) - horizontalRadius;
        int y = center.getY() + random.nextInt(verticalRadius * 2 + 1) - verticalRadius;
        int z = center.getZ() + random.nextInt(horizontalRadius * 2 + 1) - horizontalRadius;
        return new BlockPos(x, y, z);
    }

    private static String formatPos(BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }
}
