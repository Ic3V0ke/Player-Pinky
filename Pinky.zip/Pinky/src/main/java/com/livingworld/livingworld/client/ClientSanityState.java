package com.livingworld.livingworld.client;

public final class ClientSanityState {
    private static int sanity;
    private static int sanityMax = 100;
    private static int recentEventTicks;

    private ClientSanityState() {
    }

    public static void update(int newSanity, int newSanityMax, int newRecentEventTicks) {
        sanity = Math.max(0, newSanity);
        sanityMax = Math.max(1, newSanityMax);
        recentEventTicks = Math.max(0, newRecentEventTicks);
    }

    public static int getSanity() {
        return sanity;
    }

    public static int getSanityMax() {
        return sanityMax;
    }

    public static int getRecentEventTicks() {
        return recentEventTicks;
    }

    public static float getNormalized() {
        return Math.min(1.0F, sanity / (float) sanityMax);
    }
}
