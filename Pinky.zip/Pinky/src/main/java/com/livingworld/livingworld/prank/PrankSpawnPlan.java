package com.livingworld.livingworld.prank;

import net.minecraft.resources.ResourceLocation;

import java.util.List;

public record PrankSpawnPlan(int lifetimeTicks, String chatMessage, List<SpawnEntry> entries) {
    public record SpawnEntry(ResourceLocation entityTypeId, double x, double y, double z, float yRot) {
    }
}
