package com.livingworld.livingworld.util;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

public final class WorldSightUtil {
    private WorldSightUtil() {
    }

    public static boolean isBlockObserved(ServerPlayer player, BlockPos blockPos, double angleDegrees) {
        Vec3 target = Vec3.atCenterOf(blockPos);
        if (!isPointObserved(player, target, angleDegrees)) {
            return false;
        }

        Vec3 eyePosition = player.getEyePosition();
        BlockHitResult hitResult = player.level().clip(new ClipContext(
                eyePosition,
                target,
                ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE,
                player
        ));

        return hitResult.getType() == HitResult.Type.BLOCK && hitResult.getBlockPos().equals(blockPos);
    }

    public static boolean isEntityObserved(ServerPlayer player, Entity entity, double angleDegrees) {
        Vec3 target = entity.getEyePosition();
        return isPointObserved(player, target, angleDegrees) && player.hasLineOfSight(entity);
    }

    public static boolean isPointObserved(ServerPlayer player, Vec3 point, double angleDegrees) {
        Vec3 look = player.getLookAngle().normalize();
        Vec3 toPoint = point.subtract(player.getEyePosition());

        if (toPoint.lengthSqr() < 0.0001D) {
            return true;
        }

        Vec3 toPointNormalized = toPoint.normalize();
        double dot = look.dot(toPointNormalized);
        double threshold = Math.cos(Math.toRadians(angleDegrees));
        return dot >= threshold;
    }

    public static Optional<BlockPos> findSpawnBehindPlayer(ServerLevel level, ServerPlayer player, int minDistance, int maxDistance, int attempts) {
        RandomSource random = level.random;

        for (int i = 0; i < attempts; i++) {
            float angleOffset = 140.0F + random.nextFloat() * 80.0F;
            float direction = random.nextBoolean() ? 1.0F : -1.0F;
            float degrees = player.getYRot() + 180.0F + angleOffset * direction;
            float radians = (float) Math.toRadians(degrees);
            int distance = Mth.nextInt(random, minDistance, maxDistance);

            int x = Mth.floor(player.getX() + Math.cos(radians) * distance);
            int z = Mth.floor(player.getZ() + Math.sin(radians) * distance);
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);

            BlockPos feetPos = new BlockPos(x, y, z);
            BlockPos headPos = feetPos.above();
            BlockState feetState = level.getBlockState(feetPos);
            BlockState headState = level.getBlockState(headPos);

            if (!feetState.isAir() || !headState.isAir()) {
                continue;
            }

            if (isBlockObserved(player, feetPos, 50.0D)) {
                continue;
            }

            return Optional.of(feetPos);
        }

        return Optional.empty();
    }

    public static Direction randomHorizontalDirection(RandomSource random) {
        Direction[] directions = new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};
        return directions[random.nextInt(directions.length)];
    }
}
