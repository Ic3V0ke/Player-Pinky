package com.livingworld.livingworld.prank;

import net.minecraft.core.BlockPos;

import java.util.List;

public record PrankBlockPlan(int lifetimeTicks, String chatMessage, List<BlockChange> changes) {
    public record BlockChange(BlockPos pos, int fromStateId, int toStateId) {
    }
}
